<?php
  session_start();
  
      if(!isset($_SESSION['userid']))
         echo "<script>window.location.href='index.html'</script>";

    
  $servername = "localhost";
  $username = "root";
  $password = "Helloworld@123";
  $dbname = "mmepapp";
   
     $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
    }
    
?>


<script>
  
var whichPlanOpenId=0;
var memberSelectedGlobal=-1;
//$('#head-label').html('Create Diet Plan')
</script>

<div class="row" style="">
<div class="col-sm-3 col-xs-12">
<div style="min-height:80vh;   background-color:white; box-shadow:2px 2px 2px lightgray;" >
     <div class="input-group mb-3">
    <input type="text" class="form-control" id="srcrec" placeholder="Search">
    <div class="input-group-append">
      <button class="btn btn-primary" type="submit">Go</button>  
     </div>
  </div>
<style>
.nav-tabs:hover{
cursor:pointer;
}
.fil:hover{
cursor:pointer;

}
</style>

<script>
$('#fil').on('click',function(){
if($('#fili').hasClass('fa-plus'))
   {
$('#fili').removeClass('fa-plus');
$('#fili').addClass('fa-minus');
}
else
{$('#fili').addClass('fa-plus');
$('#fili').removeClass('fa-minus');
}
$('#filter').slideToggle();

});
</script>


<div id="fil" style="    padding: 10px;
    font-size: 15px;
        color: #009688;"><i id="fili" class="fas fa-plus"></i> filter</div>
<div class="has-shadow" id="filter" style="padding:15px; display:none;">
<?php 
    $sql="select * from hRecipe_Property";
    $rs=mysqli_query($conn,$sql);
    
    $chkcnt=0;
    while($row=mysqli_fetch_assoc($rs))
    {
        $chkcnt++;
    $pid=$row['PropId'];
                            ?>
                          
                                <div>
                                    <input id="checkboxCustom<?php echo $pid; ?>" type="checkbox" value="" class="checkbox-template"/>
                                    <label for="checkboxCustom<?php echo $pid; ?>"><?php echo $row['PropName']; ?> </label>
                                </div>
                          <? 
    }
?>


<center><div class="btn btn-primary mb-3 mt-3" onclick='filterIt()'>Apply</div></center>
</div>

  <div style="padding: 10px;">
    
    <ul class="nav nav-tabs" >
  <li class="nav-item">
    <a class="nav-link active" id="btnone" >Recipes</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" id="btntwo" >All</a>
  </li>
  
</ul>
<script type="text/javascript">
  var chkcnt=0;
</script>

   <div id="onetab" style="box-shadow:1px 1px 2px lightgrey, 1px -1px 2px lightgray; height:80vh; overflow:auto; padding:0px 25px; ">


              







    </div>


       <div id="sectab" style="display:none;box-shadow:1px 1px 2px lightgrey, 1px -1px 2px lightgray; height:80vh; overflow:auto; padding:0px 25px; ">
              




    </div>

    
  </div>
</div>
</div>


 <!-- The Modal -->
  <div class="modal fade" id="modalMeal"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Meal</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary" type="button">Meal Name</button>
      
    </div>
    <input type="text" id="RecName" class="form-control">
  </div>
<div class="input-group mb-3">
    <div class="input-group-prepend">
     <button class="btn  btn-primary" type="button">Time</button>
    </div>
    <input type="time" id="RecTime" class="form-control">
  </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="if($('#RecName').val().trim().length==0){$('#RecName').css('border','2px solid red'); event.stopPropagation();  return;}else{$('#RecName').css('border','');} if($('#RecTime').val().trim().length==0){$('#RecTime').css('border','2px solid red'); event.stopPropagation(); return;}else{$('#RecTime').css('border','');} addMeal()">Ok</button>
        </div>
        
      </div>
    </div>
  </div>




 <!-- The Modal -->
  <div class="modal fade" id="modalRecipeQuantity"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Recipe</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary" type="button">Quantiy</button>
      
    </div>
    <input type="number" value="0" id="RecQuant" class="form-control">
  </div>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="if(($('#RecQuant').val()=='0')){$('#RecQuant').css('border','2px solid red'); event.stopPropagation(); return;}else{$('#RecQuant').css('border','');} addRecipe()">Ok</button>
        </div>
        
      </div>
    </div>
  </div>

  

   <!-- The Modal -->
  <div class="modal fade" id="modalAddRecipe" data-call="0" data-DietId="0"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Recipe</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Recipe Id</button>

    </div>
    <input type="text" id="Recipe-ID" class="form-control">
  </div>

        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="addRecipe()">Ok</button>
        </div>
        
      </div>
    </div>
  </div>


  <!-- The Modal -->
  <div class="modal fade" id="modalMemSelect"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Select Member</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Member</button>

    </div>
    <select class="form-control" id="memSelect">
      <option value="all">Select All Member</option>
      <?php
          
        $sql="select * from hMember_Demo where userid='".$_SESSION['userid']."' and Mb_Status='active'";
        $rs=mysqli_query($conn,$sql);
        if(mysqli_num_rows($rs)>0){
          while($row=mysqli_fetch_assoc($rs)){
            echo '<option value="'.$row['Mb_ID'].'">'.$row['Mb_Name'].' ('.$row['Mb_ID'].')</option>';
          }
        }
      ?>
    </select>
  </div>

        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="refresh()" >Ok</button>
        </div>
        
      </div>
    </div>
  </div>



  <!-- The Modal -->
  <div class="modal fade" id="modalAddPlan"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Plan</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">


       <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Plan Name</button>

    </div>
    <input type="text" id="planName" class="form-control">
  </div>   


   <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Date</button>

    </div>
    <input type="date" id="planDate" class="form-control">
  </div>
</div>
       
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" id='addNewPlanBtn' onclick=" if($('#planName').val().trim().length==0){$('#planName').css('border','2px solid red'); event.stopPropagation(); return; }else{$('#planName').css('border','');}  if($('#planDate').val().trim().length==0){$('#planDate').css('border','2px solid red');event.stopPropagation(); return;}else{$('#planDate').css('border','');} addNewPlan();">Ok</button>
        </div>
        
      </div>
    </div>
  </div>



  <!-- The Modal -->
  <div class="modal fade" id="modalCopyPlan"  data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Copy Plan</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">


      


   <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Date</button>

    </div>
    <input type="date" id="plancDate" class="form-control">
  </div>

       
       
       <div class="input-group mb-3">
    <div class="input-group-prepend">
 <button class="btn  btn-primary"  type="button">Assign to</button>

    </div>
    <select class="form-control" id="memcSelect">
      <option value="all">Select Member</option>
      <?php
          
        $sql="select * from hMember_Demo userid='".$_SESSION['userid']."' and Mb_Status='active'";
        $rs=mysqli_query($conn,$sql);
        if(mysqli_num_rows($rs)>0){
          while($row=mysqli_fetch_assoc($rs)){
            echo '<option value="'.$row['Mb_ID'].'">'.$row['Mb_Name'].' ('.$row['Mb_ID'].')</option>';
          }
        }
     
?>

    </select>
  </div>
      </div>   
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" id='addCopyPlanBtn' >Ok</button>
        </div>
        
      </div>
    </div>
  </div>






<div class="col-sm-6 col-xs-12" style="padding-left:0px!important;padding-right:0px!important;">
 <div id="refresh">
 <div class="d-flex">
 <div style="" class="mb-3 mt-3 d-flex">
   <button id="plusAddPlanBtn" onclick="$('#modalAddPlan').modal();" style="font-size: 25px;font-weight: 600; border-radius: 50%; " class="has-shadow btn btn-primary"><span class="fas fa-plus"></span></button>
   <div id="showPlanMsg"  >
     Add New Plan
   </div>
 </div>
  <div id="alert1" style="padding-left:15px; width:100%;">

    <div class="mt-3 mb-3 alert  alert-dismissible fade " id="alrt">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <div id='alrtContent'><strong>Success!</strong> Meal Added!!.
      </div>
  </div>

  </div>

  </div>
  <!-- <button class="btn btn-primary" id="bmat" ><i class="fas fa-plus"></i></button>-->
<div  style=" background-color:white; box-shadow:2px 2px 2px lightgray; padding: 10px; " >

<div id="plans" class="text-center" style="height:80vh;overflow-y:scroll;">

</div>
    
</div>
</div>
</div>


<div class="col-sm-3 col-xs-12">
<div style="min-height:80vh;  padding:10px; background-color:white; box-shadow:2px 2px 2px lightgray;" >
   <h3 class="text-center">Member Details</h3>
   <div style='    display: flex;
    justify-content: center;'><img src='https://upload.wikimedia.org/wikipedia/commons/7/7e/Circle-icons-profile.svg' style='width:100px;height:100px; border-radius:50%;'/>

    </div>
    <div id="memdet" style='margin-top:10px;'>

</div> 
</div>
</div>




<script>
if(!$('nav').hasClass('shrinked'))
 $('#toggle-btn').click();

 $('#btnone').on('click',function(){
 
    $('#btnone').addClass('active');
    $('#btntwo').removeClass('active');
    $('#onetab').css('display','inherit');
    $('#sectab').css('display','none');
 
 });

 $('#btntwo').on('click',function(){
 
    $('#btntwo').addClass('active');
    $('#btnone').removeClass('active');
     
    $('#onetab').css('display','none');
    $('#sectab').css('display','inherit');
 });

function addMeal(){

var i=$('#modalMeal').attr('data-calledfrom');
 
cardCount++;
alert(cardCount);
 var htm=$('#PlanDetail'+i).html();
//alert(htm);
var str="<form   id='frm"+cardCount+"' data-mealName='"+$('#RecName').val()+"'  data-mealtime='"+$('#RecTime').val()+"' data-dietId='"+$('#modalMeal').attr('data-dietid')+"' data-planDate='"+$('#modalMeal').attr('data-dietdate')+"' data-planName='"+$('#DietName'+i).html()+"'   style='display: inline-block;' class='ng-pristine ng-valid'><div   class='card card2' ><div class='card-body'><h2 class='card-title'>"+$('#RecName').val()+"</h2><small>"+$('#RecTime').val()+"</small></div><div class='card-img-bottom' id='cardimg"+cardCount+"'><div class='addrecipe' onclick='event.stopPropagation();addingRecipe("+cardCount+");chngcolor("+cardCount+");' style=' color:lightgray ;    padding: 5px;border: 3px dashed lightgray;'><i class='fas fa-plus'></i> Add Here</div></div></div></form>";

var final=htm+str;
$('#PlanDetail'+i).html(final);

}
function chngcolor(cnt){
  $('.addrecipe').each(function(i,o){
 $(o).parents('div[class^="card-img-bottom"]').eq(0).css('background-color','#f7f7f7');
  });
$('#cardimg'+cnt).css('background-color','#796aee17');
}
function addingRecipe(cnt) {
 // $('#modalAddRecipe').modal('show');
 $('#modalAddRecipe').attr('data-call',cnt);

}

function current(obj,id){

  $(obj).css('border','1px solid lightgray');
var a=obj.cloneNode(true);
$(a).addClass('newone');
//var x=a.getElementById('PlanDetail'+id);
//x.style.backgroundColor="black";
$(".newone")[0].addClass('reddddd');
$('#curplan').html('');
  $('#curplan').append(a);
$('#PlanDetail'+id).slideToggle();


}
function addRecipe(){

if($('#memSelect').val()=='all')
{ $('#alrt').addClass('alert-danger');
    $('#alrtContent').html('<strong>Cannot add recipe</strong>, Select a member first');
    $('#alrt').addClass('show');
    setTimeout(function(){$('#alrt').removeClass('show');
      $('#alrt').removeClass('alert-success');
  },2500);
return;
}


var image="";
  var id=$('#modalAddRecipe').attr('data-call');

      var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

   if(this.readyState == 4 && this.status == 200){
    var ar=JSON.parse(this.responseText);
    $('#modalAddRecipe').attr('data-DietId',ar[0]); 
   if($('#frm'+id).attr('data-dietId')==0)
    {
       $('#frm'+id).attr('data-dietId',ar[0]);
 var at=$('#'+$('#frm'+id).attr('data-planName')).attr('onclick');
          
 $('#'+$('#frm'+id).attr('data-planName')).attr('onclick',at+"$('#modalMeal').attr('data-dietid','"+ar[0]+"');");
 
     }   
   if(ar[1]=='Success'){
    $('#alrt').addClass('alert-success');
    $('#alrtContent').html('<strong>Success</strong> Meal Added!!');
    $('#alrt').addClass('show');
    setTimeout(function(){$('#alrt').removeClass('show');
      $('#alrt').removeClass('alert-success');
  },2500);
   
   }
  image=ar[2];
var recnm=ar[3];
var recid=ar[4];



 var htm= $('#cardimg'+id).html();

var str="<div class='mb-3 has-shadow recadded' style=' '><div style='width:50px; height:50px;' class='has-shadow' ><img  src='"+ar[2]+"' class='img-fluid'/></div><div style='padding-left: 10px;'><div class='text'><h3 class='h4'>"+recnm+"</h3><strong style='color: #aaa;font-size: 0.75em;'><i class='fas fa-balance-scale'></i> "+$('#RecQuant').val()+"</strong></div></div><div class='close' onclick='event.stopPropagation();deleteRecipe(&#39;"+recid+"&#39;,this)'><i class='icon-close'></i></div></div>";
var final=str+htm;
$('#cardimg'+id).html(final);
//refresh();

  }

};
var dId=$('#modalAddRecipe').attr('data-DietId');

xmlhttp.open('POST','response.php?flag=dietPlan&mn='+$('#frm'+id).attr('data-mealName')+'&mt='+$('#frm'+id).attr('data-mealtime')+'&dId='+$('#frm'+id).attr('data-dietId')+'&rid='+$('#Recipe-ID').val()+'&mid='+$('#memSelect').val()+'&pd='+$('#frm'+id).attr('data-planDate')+'&pn='+$('#frm'+id).attr('data-planName')+'&rq='+$('#RecQuant').val(),true);


if($('#modalAddRecipe').attr('data-call')!=0)
 xmlhttp.send();

}

function addmeRecipe(id){

$('#Recipe-ID').val(id);
if($('#modalAddRecipe').attr('data-call')!=0)
$('#modalRecipeQuantity').modal();
else{

  $('#alrt').addClass('alert-danger');
  $('#alrtContent').html('<strong>No Meal Selected!!</strong>');
   $('#alrt').addClass('show');
    setTimeout(function(){$('#alrt').removeClass('show');
$('#alrt').removeClass('alert-warning');
  },2500);
}

}


  $(function(){
 
  
if(memberSelectedGlobal==-1)
    $('#modalMemSelect').modal();
  else
    $('memSelect').val()=memberSelectedGlobal;
  

 /*
    var x1=new XMLHttpRequest();
  x1.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  $('#sectab').html(this.responseText);
  }
  };
  x1.open('GET','response.php?flag=dietrecview2');
  x1.send();
  */
  });

$('memSelect').on('change',function(){
memberSelectedGlobal = $('memSelect').val();
});

var DietCount=1;
function showDietPlan(){
 $('#modalAddRecipe').attr('data-DietId',$('#memSelect').val());
 

loadmemdet();

}
$('#plans').scroll(function() {

  if(Math.floor($('#plans').scrollTop())==(Math.floor($('#plans').prop('scrollHeight')-$('#plans').height())))
    { 
   dview++;
        var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  var ar=JSON.parse(this.responseText);
  $('#plans').append(ar[0]);
  cardCount=ar[1];
  alert();
        DietCount=ar[2];
        DietCount++;
fillname();
  if(whichPlanOpenId!=0)
$('#'+whichPlanOpenId).css('display','block');

  loadimg();
  }
  
  };
  x.open('GET','response.php?flag=dietPlanView&mid='+$('#memSelect').val()+'&f='+dview);
  x.send();
    }
  });

var dview=0;
function loadview(){
dview++;
 var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

   if (this.readyState == 4 && this.status == 200) {
          var ar=JSON.parse(this.responseText);
      var htm=$('#plans').html();
     var rcv=ar[0];
        $('#plans').html(htm+rcv);
        cardCount=ar[1];
        alert(cardCount)
        DietCount=ar[2];
        DietCount++;


 $('#modalAddRecipe').attr('data-DietId',$('#memSelect').val()); 

fillname();
if(whichPlanOpenId!=0)
$('#'+whichPlanOpenId).css('display','block');
loadrec1();
  }
};

var dId=$('#memSelect').val();
xmlhttp.open('POST','response.php?flag=dietPlanView&mid='+$('#memSelect').val()+'&f=1',true);
 if($('#modalAddRecipe').attr('data-DietId')!=0)
 xmlhttp.send();
 
 


}
function loadmemdet(){

   var xmlhttp1 = new XMLHttpRequest();
        xmlhttp1.onreadystatechange = function() {

   if (this.readyState == 4 && this.status == 200) {
         
$('#memdet').html(this.responseText);
    loadview(); 

  }
  
}; 

xmlhttp1.open('POST','response.php?flag=memdetail&mid='+$('#memSelect').val(),true);
 if($('#modalAddRecipe').attr('data-DietId')!=0)
 xmlhttp1.send();

}
  $('#onetab').scroll(function() {

  if(Math.floor($('#onetab').scrollTop())==(Math.floor($('#onetab').prop('scrollHeight')-$('#onetab').height())))
    { 
   rec1++;
        var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  $('#onetab').append(this.responseText);
loadimg();
  }
  
  };
  x.open('GET','response.php?flag=dietrecview1&f='+rec1);
  x.send();
    }
  });

  $('#sectab').scroll(function() {

  if(Math.floor($('#sectab').scrollTop())==(Math.floor($('#sectab').prop('scrollHeight')-$('#sectab').height())))
    { 
   rec2++;
        var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  $('#sectab').append(this.responseText);
loadimg();
  }
  
  };
  x.open('GET','response.php?flag=dietrecview2&f='+rec2);
  x.send();
    }
  });

var rec1=0;
function loadrec1(){
rec1++;
  var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  $('#onetab').html(this.responseText);
  loadrec2();
  }
  
  };
  x.open('GET','response.php?flag=dietrecview1&f='+rec1);
  x.send();

}
var rec2=0;
function loadrec2(){
rec2++; 
var x1=new XMLHttpRequest();
  x1.onreadystatechange=function(){
  if(this.status == 200 && this.readyState == 4 )
  {
  $('#sectab').html(this.responseText);
 loadimg();
  }
  };
  x1.open('GET','response.php?flag=dietrecview2&f='+rec2);
  x1.send(); 

}


function loadimg(){ 
$('.loadimg').each(function(i, obj) {
   var at= $(obj).attr('data-img');
  $(obj).attr('src',at);
  $(obj).removeClass('loadimg');
});

}

function  fillname(){
$('.card-title').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Meal Name'); 
});


$('.card-body small').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Meal Time'); 
});

$('.DietName').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Plan Name'); 
});

}

var ownerId=<?echo $_SESSION['userid'];?>;
/*
$('#plusAddPlanBtn').on('click',function(){
$('#modalAddPlan').modal();

});

*/
function filterIt(){
var chkarr=new Array();
   for (var i=0;i<chkcnt;i++){
                chkarr[i]=$('#checkboxCustom'+(i+1)).is(":checked");
            }


var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

   if(this.readyState == 4 && this.status == 200){
       
        $('#onetab').html(this.responseText);
  

}
};

xmlhttp.open('POST','response.php?flag=recipelist&chk='+JSON.stringify(chkarr),true);

 xmlhttp.send();
            

}

function deleteRecipe(id,ele){

var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

   if(this.readyState == 4 && this.status == 200){
       if(this.responseText){
        var e=$(ele).parent().closest('div');
        $(e).remove();
         $('#alrt').addClass('alert-success');
    $('#alrtContent').html('<strong>Success</strong> Meal Deleted!!');
    $('#alrt').addClass('show');
    setTimeout(function(){$('#alrt').removeClass('show');
      $('#alrt').removeClass('alert-success');
  },2500);

       }else{

         $('#alrt').addClass('alert-danger');
    $('#alrtContent').html('<strong>Error</strong> Try again!');
    $('#alrt').addClass('show');
    setTimeout(function(){$('#alrt').removeClass('show');
      $('#alrt').removeClass('alert-danger');
  },2500);

       }
  
}

};

xmlhttp.open('POST','response.php?flag=deleteRecipefromplan&id='+id,true);

 xmlhttp.send();

}

function copyPlan(pid){

$('#modalCopyPlan').modal();
$('#addCopyPlanBtn').unbind().click(function(){

  var x=new XMLHttpRequest();
  x.onreadystatechange=function(){
    if(this.status==200&&this.readyState==4){
      if(this.responseText)
        alert('good');
     // refresh();
    }
  };
    x.open('GET','response.php?flag=copyplan&planid='+pid+'&mid='+$('#memcSelect').val()+"&pd="+$('#plancDate').val());
    x.send();

  });
}

function addNewPlan(){
var p=$('#plans').html();


var str="<div class='project' id='Diet"+DietCount+"' onclick='toggle(&quot;PlanDetail"+DietCount+"&quot)' style=' transition: all 0.3s cubic-bezier(.25,.8,.25,1);'>   <div class='row bg-white has-shadow'>   <div class='left-col col-lg-6 d-flex align-items-center justify-content-between'>   <div class='project-title d-flex align-items-center'>   <div class='text'>   <h3 class='h4 DietName' id='DietName"+DietCount+"'>"+$('#planName').val()+"</h3><small>Owner Dietician "+ownerId+"</small>   </div>   </div>   <div class='project-date'><span class='hidden-sm-down'><span style='color:orange'>"+$('#planDate').val()+"</span></span></div>   </div>   <div class='right-col col-lg-6 d-flex align-items-center'>   <div class='time'><i class='fas fa-balance-scale'></i>300 gm </div>   <div class='comments'><i class='far fa-comments'></i>20</div>   <div class='project-progress' style='width:130px;'>   <div class='progress'>   <div role='progressbar' style='width: 45%; height: 6px;' aria-valuenow='25' aria-valuemin='0' aria-valuemax='100' class='progress-bar bg-red'></div>   </div>   </div>   </div>   <div id='PlanDetail"+DietCount+"' class='hideit accord'>  <form  style='display: inline-block;' class='ng-pristine ng-valid' > <div class='card card2' id='"+$('#planName').val()+"'  onclick='event.stopPropagation(); $( &#39;#modalMeal &#39; ).modal();  $(&#39;#modalMeal&#39;).attr(&#39;data-calledfrom&#39;,&#39;"+DietCount+"&#39;);    $(&#39;#modalMeal&#39;).attr(&#39;data-dietid&#39;,&#39;"+0+"&#39;); $(&#39;#modalMeal&#39;).attr(&#39;data-dietdate&#39;,&#39;"+$('#planDate').val()+"&#39;);' ><div class='card-body'><input name='6th' type='hidden' > <h2 class='card-title'>Add Meal</h2> <small>Add new Meal plan</small> </div> <div class='card-img-bottom' style='border:5px dashed lightgray;'> <i id='onei' class='fas fa-plus' style=' position: relative; top: 50%; color:lightgray; left: 50%; transform: translate(-50%,-50%); font-size: 70px;'></i> </div> </div> </form></div></div></div>";
$('#plans').html(str+p);
DietCount++;

fillname();
}


function toggle(id){
whichPlanOpenId=id;
$('.accord').each(function(i,o){
  $(o).slideUp();
});

if($("#"+id).css("display")!='block') 
$("#"+id).slideToggle();
}




function refresh(){

if(whichPlanOpenId==0)
showDietPlan();
else
 {$('#refresh').unbind().load('dietplansub.php',function(){
    //alert(whichPlanOpenId);
     //showDietPlan();
     loadview();


});
}

}


$('#srcrec').keyup(function(){
 srcrec();
});



      function srcrec(){

       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
                if(this.status==200 && this.readyState==4)
                     {
                        $('#onetab').html(this.responseText);
                    }

                  }
    x.open('POST','response.php?srcrec='+$('#srcrec').val()+'&flag=reclistsrc');
    x.send();
}

</script>

<style>
.tab{
 background:#eef5f9;
}

#bmat{
border-radius:50%;
}
.showit{
display:block;
}
.hideit{

display:none;
}
.project:hover{

cursor:pointer;

}

.card-body{
background-color:#796aee17;
    padding-bottom: 0.5rem;
}
  .card2{
   font-size:18px;
  font-weight:400;
    border-radius: 5px 5px 5px 5px;
    display: inline-block;
    background-color: #f7f7f7;
    width: 250px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    margin-top: 10px;
    margin-left: 10px;
    margin-right:10px;
    margin-bottom: 10px;
    transition: all 0.3s cubic-bezier(.25,.8,.25,1);

  }
  .card2:hover{
    cursor: pointer;
  }
.card2:hover {
    box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}
 .card2 > .card-img-bottom{
    width: 250px;
    height: 300px;
    border-radius: 5px 5px 0px 0px;
   // background-color: #dc6b3f;
    text-align: left;
    color: #fff;
    padding: 5% 5% 7% 8%;
    min-height: 75px;
overflow:auto;
  }
.card2:hover .card-img-bottom{
color:gray !important;
border-color:gray !important;
}

 .card2 > .card-img-top{
    width: 300px;
    height: 300px;
    border-radius: 5px 5px 0px 0px;
   // background-color: #dc6b3f;
    text-align: left;
    color: #fff;
    padding: 8% 5% 7% 8%;
    min-height: 75px;
overflow:auto;
  }
.card2:hover .card-img-top{
color:gray !important;
border-color:gray !important;
}
.card2:hover #onei{

color:gray!important;
}

.addrecipe:hover{
border-color:gray !important;
color:gray!important;
}
.addrecipe:hover i{
color :gray !important;
}
#plusAddPlanBtn{
transition: all 0.3s;
width:50px;
height: 50px;
}
#plusAddPlanBtn:hover{
transform: rotate(180deg);
}
/*
#plusAddPlanBtn:hover + #showPlanMsg{
opacity: 1;
padding-left: 10px;
}*/

#showPlanMsg{
      width: max-content;
    display: flex;
    align-items: center;
   transition: all 0.3s;
padding-left: 10px;
    font-size: 18px;
    font-weight: 600;
  //  opacity:0;
}
.recadded:hover{
//box-shadow:-56px 0px 49px #00000024 inset;
}
.recadded:hover .close{
visibility: unset ;
 
}
.recadded .close{
visibility: hidden;

}

.recadded {
transition:none;
background-color:white; color:black!important;width:100%; padding: 5px;     display: flex;justify-content: space-between; align-items:center;

}
</style>