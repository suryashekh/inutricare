<?php
session_start();

    if(isset($_SESSION['userid'])){
  
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";
 
 $conn = mysqli_connect($servername, $username, $password, $dbname);
  if (!$conn) {
      die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
  }
  

  
?>

<div class="container-fluid" style="padding 0 30px;">
<style>
.project:hover{

cursor:pointer;
 box-shadow:0 1px 4px rgba(0,0,0,0.25), 0 1px 25px rgba(0,0,0,0.22);
 
}

.icon{

    width: 40px;
    height: 40px;
    line-height: 40px;
    text-align: center;
    min-width: 40px;
    max-width: 40px;
    border-radius: 50%;
    
}

.justify-center{
justify-content:center;
}

.text > strong{
font-size:30px;
}
 .text > .prop{
font-size: 15px !important;
}

.text{
padding-top:20px;
padding-left:20px;
}

.project .row{
	width:100% !important;
}

 
</style>
<script>


function selectView(id){

$('#cont-to-hide'+id).slideToggle(500,'linear');

}



function EditRecipe(id,Rarr){
	//alert(Rarr['Approved']);
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
	if(this.readyState==4 && this.status==200)
		{
		 $('#sec-to-show').load('RecipeAdd.php');
		}
	};
	xhr.open('POST','response.php?flag=4&id='+id+'&Rarr='+Rarr,true);
	xhr.send();
}

function Approve(id){
	//alert(Rarr['Approved']);
	var xhr=new XMLHttpRequest();
	xhr.onreadystatechange=function(){
	if(this.readyState==4 && this.status==200)
		{
		  
          $('#sec-to-show').load('PendingApproval.php');
		alert(this.responseText);
		}
	};
	xhr.open('POST','response.php?flag=8&Rid='+id,true);
	xhr.send();
}


</script>

<?php
   $sql="SELECT * FROM `hDietician_Enrollment` where Dt_Userid='".$_SESSION['userid']."'";
  $result3=mysqli_query($conn,$sql);
  $rowP=mysqli_fetch_assoc($result3);
  $pen=json_decode($rowP['Dt_PendingApproval']);
  if(count($pen)<1)
  {
  echo "<div class='row' style='    justify-content: center; color: #949b9d;font-size: 20px;'> <div>No Pending Approval</div> </div>";
  
  }
  foreach ($pen as $pRid)
 {
  $sql="select * from hRecipes where Recipe_ID='".$pRid."'";
  $result2=mysqli_query($conn,$sql);
  $Rtempid="";
  $Rtempnm="";
  $Rseltemp="";
    if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     { 
     	 
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
         $Rtempen=$row2['Energy_Kcal'];
         $Rtempap=$row2['Approved'];
        
          $RtempEnK=$row2['Energy_Kcal'];
           $RtempFats=$row2['Fats'];
            $RtempCarbohydrate=$row2['Carbohydrate'];
             $RtempProtein=$row2['Protein'];
              $RtempFibre=$row2['Fibre'];
               $RtempWater=$row2['Water'];
               $RtempUofM=$row2['Unit_Of_Measure'];
               $RtempQ=$row2['Quantity'];
	         $RtempProp=$row2['Properties'];

         $RtempId=$row2['Recipe_ID'];
         
          $sql= "SELECT * FROM `hRecipe_Steps` WHERE `Rid`='".$RtempId."' order by sno";
         $res=mysqli_query($conn,$sql);
         $stepstr=array();
        
          if(mysqli_num_rows($res)>0){
	         while($r = mysqli_fetch_assoc($res))
	         {
	         	array_push( $stepstr,$r['steps']);
	         }
         }
           $Rtempstep=$stepstr;
         

?>

<div class="project"  id="<?php echo $RtempId; ?>"  onclick=selectView(<?php echo $RtempId; ?>) style=" transition: all 0.3s cubic-bezier(.25,.8,.25,1);">
                <div class="row bg-white has-shadow">
                  <div class="left-col col-lg-6 d-flex align-items-center justify-content-between">
                    <div class="project-title d-flex align-items-center">
                      <div class="image has-shadow"><img src='' data-img="<?php if($Rtemppc=='/') echo 'preview.jpg'; else echo $Rtemppc;  ?>"  class="loadimg img-fluid"></div>
                      <div class="text">
                        <h3 class="h4"><?php echo $Rtempnm; ?></h3><small><?php echo $Rtempen; ?> Kcal</small>
                      </div>
                    </div>
                    <div class="project-date"><span class="hidden-sm-down"><?php if( $Rtempap == 'true') echo "<span style='color:lightgreen'>Approved</span>"; else echo "<span style='color:orange'>Approval pending</span>";  ?></span></div>
                  </div>
                  <div class="right-col col-lg-6 d-flex align-items-center">
                    <div class="time"><i class="fas fa-balance-scale"></i><?php echo $RtempQ." ".$RtempUofM ; ?> </div>
                    <div class="comments"><i class="far fa-comments"></i>20</div>
                    <div class="project-progress" style="width:150px;">
                      <div class="progress">
                        <div role="progressbar" style="width: 45%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                      </div>
                    </div>
                   
                    <div >
                    <button class="btn btn-primary" id="RecipeApprove" onclick='event.stopPropagation(); Approve(<?php  echo $RtempId;?>)'>Approve</button>
                   <button class="btn btn-primary" id="RecipeEdit" onclick='event.stopPropagation(); EditRecipe(<?  echo $RtempId;?>,"<? echo addslashes(json_encode($row2));?>")'>Edit</button>
                    </div>
                  </div>
                 
                  <div id="cont-to-hide<?php echo $RtempId; ?>" style="width:100%; display:none;">
                    <div class="line"></div>
                  <div class="row">
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center " style="justify-content:center;">

                      		<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" ><strong><?php echo $RtempFats; ?></strong><br><small class="prop">Fat</small></div>

                      </div>
                      
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                      	<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" style="padding-top: 10px;"><strong><?php echo $RtempEnK; ?></strong><br><small class="prop">Energy</small></div>

                      </div>
                  

                   	
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                      		<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" ><strong><?php echo $RtempCarbohydrate; ?></strong><br><small class="prop">Carbohydrate</small></div>

                      </div>
                   
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center " style="justify-content:center;">

                      	<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong><?php echo $RtempProtein; ?></strong><br><small class="prop">Protein</small></div>

                      </div>
                  

                   
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                      		<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong><?php echo $RtempFibre; ?></strong><br><small class="prop">Fibre</small></div>

                      </div>
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                      	<div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong><?php echo $RtempWater; ?></strong><br><small class="prop">Water</small></div>

                      </div>
                   </div>
		 <div class="line"></div>
                            <h3 class="h4" style="text-align:center; font-size:25px; ">Properties</h3>
                          <div class="row" style="justify-content: space-evenly;">
                          <?php 
                           $arrchk=  json_decode($RtempProp); 
                           $sql3="select * from hRecipe_Property";
  $result3=mysqli_query($conn,$sql3);
  $chkcnt=0;
			  while($row = mysqli_fetch_assoc($result3))
			  {
			  if($arrchk[$chkcnt]=='true')
			  echo "<div class='i-checks' style='padding: 0 10px;'>
                              <input id='checkboxCustom' type='checkbox' value='' disabled='' checked='' class='checkbox-template'>
                              <label for='checkboxCustom'>".$row['PropName']."</label>
                            </div>";
			  $chkcnt++;
			  }
                          ?>
                          </div>    
                     
              
                 <div class="line"></div>
                            <h3 class="h4" style="text-align:center; font-size:25px; ">Steps of preparation</h3>
                <div class="row" style=" padding-left:10%;   align-items: center;">
                            <ol class="list-group vertical-steps" id="stepscontainer">
                            <?php
                              $arr=  $Rtempstep; 
                             foreach($arr as $temp){
                             ?>
  <li class="list-group-item active"><span>
   <?php 
        echo $temp;
      ?>
      </span><?php } ?></li>
 
   
</ol>

        </div>            
          </div>
              </div>
   </div>
  
  <?php  
          
  } 
  
  }//num rows
  }//endinng foeach    
    }//ending if of user session
    
    else
     echo "<script>window.location.href='index.html'</script>";
    
    
?>

</div>
<script>
$(function(){

$('.loadimg').each(function(i, obj) {
   var at= $(obj).attr('data-img');
	$(obj).attr('src',at);
});


});

</script>