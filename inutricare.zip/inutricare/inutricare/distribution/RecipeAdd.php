<?
session_start();
if(isset($_SESSION['userid'])){

$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";


    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("<br><br><script> alert('connnection failed " . mysqli_connect_error()."');</script>");
    }

    $sql2="select * from hDietician_Enrollment where Dt_Designation='seniorDietician'";
    $result2=mysqli_query($conn,$sql2);
    $Rtempid="";
    $Rtempnm="";
    $Rseltemp="";
    if(mysqli_num_rows($result2)>0){
        while( $row2 = mysqli_fetch_assoc($result2))
        {
            $Rtempid=$row2['Dt_Userid'];
            $Rtempnm=$row2['Dt_Name'];
            $Rseltemp.="<option value=".$Rtempid." >".$Rtempnm."</option>";
        }
    }

    echo "<script> var Rselect='".$Rseltemp."';</script>";

    $sql="select * from hRecipe_Property";
    $rs=mysqli_query($conn,$sql);

?>


     <script src="extra.js"></script>
<style>

</style>
<div class="modal" id="errorMod1">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Error Submiting Recipe</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="errbod">
        Modal body..
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
             
<div class="col-lg-12">
    <div class="card">
        <div class="card-close">
            <div class="dropdown">
                <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
            </div>
        </div>
        <div class="card-header d-flex align-items-center">
            <h3 class="h4">Add Recipe</h3>
        </div>

        <div class="card-body">
            <input type="file" id="csvUp" style="display:none;"/>
            <input type="file" id="csvStepUp" style="display:none;"/>
            <div class="row" style="justify-content:center;">

                <a class="btn btn-primary" style="margin: 5px 5px;" href="hRecipes.csv" download>Download CSV template</a>
                <button class="btn btn-primary" style="margin: 5px 5px;" onclick="$('#csvUp').click();"> Step 1 -> Upload CSV </button>
                <button class="btn btn-primary" style="margin: 5px 5px;" id="Upstep" >Step 2 -> Upload Steps CSV</button>
            </div>

            <div class="line"> </div>
            <div class="row">
                <div class="col-sm-1"></div>
                <div class="col-sm-10">

                    <div class="form-group row" style="align-items:center; margin-bottom:3rem;">

                        <div class="col-sm-4 col-xs-12">
                            <input style="display:none;" id="RecipePhotos" type="file" class="form-control-file">
                            <div class="col-xs-12">
                                <img id="PreviewPhoto" onclick="event.stopPropagation(); openOverlay(this)" style=" position: relative;left: 50%;transform: translate(-50%);width:120px; height:120px; box-shadow:2px 2px 2px gray; position: relative; left: 50%; transform: translate(-50%);" >
                            </div>
                            <button style="position: relative; left: 50%; top: 6px; margin-bottom:10px; transform: translate(-50%);" class="btn btn-primary" onclick="$('#RecipePhotos').click();">Change Image</button>
                        </div>
                        
                        
                        <div class="col-sm-8 col-xs-12">
                            <input id="Recipename" type="text" name="Recipename" required class="input-material">
                            <label for="Recipename" style=" left: 15px;" class="label-material">Recipe Name</label>
                        </div>
                    </div>
                                   
                    <div class="form-group row" >
                    <div class="col-sm-8 col-xs-12">
                    	<input type="text" name="Recipeweight" id="Recipeweight" required class="input-material" />
                        <label for="Recipeweight" style=" left: 15px;" class="label-material  ">Unit Weight</label>
                     </div>   
                        <div class="col-sm-4 col-xs-12 select" >
                            

                    
<?php
//For Unit Measurement        
        $query = "SELECT * FROM MeasureMaster";
        $select_measurement = mysqli_query($conn,$query);
        $select = '<select name="RecipeUnit" id="RecipeUnit" class="form-control" >';
        while($row = mysqli_fetch_assoc($select_measurement)){
            $mes_title = $row['m_name'];
//            echo '<option value="'.$mes_title.'">".$mes_title."</option>";
             $select.='<option value="'.$mes_title.'">'.$mes_title.'</option>';
            
        }
        $select.='</select>';
        echo $select;

?>

			    </div>
                    </div>
                    
                                           
                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button  type="button" class="btn btn-primary">Fat (gm)</button>
                                </div>
                                <input type="text" id="Recipefat" name="Recipefat" class="form-control">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button  type="button" class="btn btn-primary">Energy (Kcal)</button>
                                </div>
                                <input type="text" id="RecipeEnergy" name="RecipeEnergy" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button type="button"  class="btn btn-primary">Carbohydrate (gm)</button>
                                </div>
                                <input type="text" id="RecipeCarbohydrate" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button type="button"  class="btn btn-primary">Protein (gm)</button>
                                </div>
                                <input type="text" id="RecipeProtein" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button type="button"  class="btn btn-primary">Fibre (gm)</button>
                                </div>
                                <input type="text" id="RecipeFibre" class="form-control">
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <button type="button"  class="btn btn-primary">Water (ml)</button>
                                </div>
                                <input type="text" id="RecipeWater" class="form-control">
                            </div>
                        </div>


                        <div class="form-group row">

                            <label class="col-sm-3 form-control-label">Reviewer Dietician </label>
                            <div class="col-sm-9 select">
                                <select id="RecipeReviewer" class="form-control">

                                </select>
                            </div>
                        </div>
                        <div class="line"></div>
                        <h3 class="h4" style="margin-bottom: 10px;">Properties</h3>
                        <div class="row" >

                            <?php
    $chkcnt=0;
    while($row=mysqli_fetch_assoc($rs))
    {
        $chkcnt++;
                            ?>
                            <div class="col-sm-4">
                                <div class="">
                                    <input id="checkboxCustom<?php echo $row['PropId']?>" type="checkbox" value="" class="checkbox-template">
                                    <label for="checkboxCustom<?php echo $row['PropId']?>"><?php echo $row['PropName']?></label>
                                </div>
                            </div>
                            <?php
    }
                            ?>
                        </div>

                        <div class="line"></div>
                        <h3 class="h4">Steps of preparation</h3>
                        <ol class="list-group vertical-steps" id="stepscontainer">
                            <li id="l0" class="list-group-item active"><span><textarea id="ta0" class="form-control"></textarea></span></li>


                        </ol>
                        <button class="btn btn-primary" style="margin-top: 30px;" onclick="addsteps()">Add</button>
                        <button class="btn btn-primary" style="margin-top: 30px;" onclick="removesteps()">Delete</button>
                        <div class="form-group-material">
                            <input id="register-button" type="button" onclick="sub()"  name="registerButton"  class="input-material btn " value="Submit Recipe" style="    width: 50%;
  position: relative;
    left: 50%;
    transform: translate(-50%,0);">
                        </div>
                        <script>
                            var EditorCopy01 =1;
                            stepsCount=1;
                            function addsteps(){
                                stepsCount++;
                                $('#stepscontainer').append("  <li id='l"+(stepsCount-1)+"' class='list-group-item active'><span><textarea id='ta"+(stepsCount-1)+"' class='form-control'></textarea></span></li>");
                            }
                            function removesteps(){
                                stepsCount--;
                                $('#l'+stepsCount).remove();
                            }
                        </script>

                    </div>
                    <div class="col-sm-1"></div>
                </div>
                <div class="line"></div>
<div class="progress">
  <div class="progress-bar progress-bar-striped active" id="prog" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">
    <span class="sr-only">0% Complete</span>
  </div>
</div>

            </div>
        </div>
    </div>
    <a id="downStep" href="Upload Steps.csv" style="display:none;" download >Upload steps </a>

    <?php
    echo "  <script>  $('#RecipeReviewer').html(Rselect); var chkcnt=".$chkcnt.";   var RId=''</script>";


    if(isset($_SESSION['Rflag'])&&($_SESSION['Rflag']==1||$_SESSION['Rflag']==2))
    {


        $RtempId=json_decode($_SESSION['Rarr1'],true);

        $sql= "SELECT * FROM `hRecipe_Steps` WHERE `Rid`='".$RtempId['Recipe_ID']."' order by sno";

        $res=mysqli_query($conn,$sql);
        $stepstr=array();

        if(mysqli_num_rows($res)>0){
            while($r = mysqli_fetch_assoc($res))
            {
                array_push( $stepstr,$r['steps']);
            }
        }
        $Rtempstep=$stepstr;

        // $arr=json_decode($_SESSION['Rarr']);
        echo "<script>var ar=".$_SESSION['Rarr1'].";

    var Rnm=ar['Recipe_Name'];
         var Rpc=ar['Recipe_Pic'];
         var Ren=ar['Energy_Kcal'];
         var Rap=ar['Approved'];
          var REnK=ar['Energy_Kcal'];
           var RFats=ar['Fats'];
            var RCarbohydrate=ar['Carbohydrate'];
             var RProtein=ar['Protein'];
              var RFibre=ar['Fibre'];
               var RWater=ar['Water'];
               var RUofM=ar['Unit_Of_Measure'];
               var RQ=ar['Quantity'];
           var RProp=ar['Properties'];
         var Rsteps=".json_encode($Rtempstep).";
         RId=ar['Recipe_ID'];
         var RDt=ar['Reviewer_Dt_Id'];

          $('#Recipename').val(Rnm);

        $('#Recipeweight').val(RQ);
        $('#RecipeUnit').val(RUofM);
        $('#Recipefat').val(RFats);
        $('#RecipeEnergy').val(REnK);
        $('#RecipeCarbohydrate').val(RCarbohydrate);
        $('#RecipeProtein').val(RProtein);
        $('#RecipeFibre').val(RFibre);
        $('#RecipeWater').val(RWater);
     $('#PreviewPhoto').attr('src',Rpc);

     var arg =RDt;
 $('#RecipeReviewer').val(arg)

  var RProp=JSON.parse(ar['Properties']);
  for(var i=0;i<chkcnt;i++)
    {
    if(RProp[i]==true)
    {
    $('#checkboxCustom'+(i+1)).attr('checked', true);
      }
    }


    stepsCount=1;
    for(var i=0;i<Rsteps.length;i++)
    {
    $('#ta'+i).val(Rsteps[i]);
     if(Rsteps.length>1)
        addsteps();
    }
    ";


        if($_SESSION['Rflag']==1)
        {
            echo "$('#register-button').val('Update Recipe'); EditorCopy01 = 0;";
        }



        echo " </script>";

        $_SESSION['Rflag']=0;
    }

}

else
{
    echo "<script>alert('Login Again'); </script>";
}

    ?>
    <script>



        var materialInputs = $('input.input-material');

        // activate labels for prefilled values
        materialInputs.filter(function() { return $(this).val() !== ""; }).siblings('.label-material').addClass('active');

        // move label on focus
        materialInputs.on('focus', function () {
            $(this).siblings('.label-material').addClass('active');
        });

        // remove/keep label on blur
        materialInputs.on('blur', function () {
            $(this).siblings('.label-material').removeClass('active');

            if ($(this).val() !== '') {
                $(this).siblings('.label-material').addClass('active');
            } else {
                $(this).siblings('.label-material').removeClass('active');
            }
        });


        function sub(){
        
var err="",ef=0;
            var nm=$('#Recipename').val();
					if(nm.trim().length==0)
                    {
                 
                   err+="Invalid Name Value, ";
                     ef=1;
            $('#Recipename').css('border','2px solid red');
                    }
        else{
        $('#Recipename').css('border','');
        }
            var wt=$('#Recipeweight').val();
					if(isNaN(wt.trim())||wt.trim().length==0)
                    {
                   err+="Invalid Weight Value, ";
                     ef=1;
            $('#Recipeweight').css('border','2px solid red');
                    }
        				 else{
        $('#Recipeweight').css('border','');
        }
        
        var unt=$('#RecipeUnit').val();
            var ft=$('#Recipefat').val();
        			if((isNaN(ft))||(ft.trim().length==0))
                    {
                   err+="Invalid Fat Value, ";
                     ef=1;
            $('#Recipefat').css('border','2px solid red');
                    }
         else{
        $('#Recipefat').css('border','');
        }
            var en=$('#RecipeEnergy').val();
        	if((isNaN(en))||(en.trim().length==0))
                    {
                   err+="Invalid Energy Value, ";
                     ef=1;
            $('#RecipeEnergy').css('border','2px solid red');
                    }
         else{
        $('#RecipeEnergy').css('border','');
        }
            var ca=$('#RecipeCarbohydrate').val();
        	if((isNaN(ca))||(ca.trim().length==0))
                    {
                  err+="Invalid Carbohydrate Value, ";
                     ef=1;
            $('#RecipeCarbohydrate').css('border','2px solid red');
                    }
         else{
        $('#RecipeCarbohydrate').css('border','');
        }
            var pr=$('#RecipeProtein').val();
        	if((isNaN(pr))||(pr.trim().length==0))
                    {
                  err+="Invalid Protein Value, ";
                     ef=1;
            $('#RecipeProtein').css('border','2px solid red');
                    }
         else{
        $('#RecipeProtein').css('border','');
        }
            var fb=$('#RecipeFibre').val();
        	if((isNaN(fb))||(fb.trim().length==0))
                    {
                  err+="Invalid Fibre Value, ";
                     ef=1;
            $('#RecipeFibre').css('border','2px solid red');
                    }
         else{
        $('#RecipeFibre').css('border','');
        }
            var wa=$('#RecipeWater').val();
        	if((isNaN(wa))||(wa.trim().length==0))
                    {
                   err+="Invalid Water Value, ";
                     ef=1;
            $('#RecipeWater').css('border','2px solid red');
                    }
         else{
        $('#RecipeWater').css('border','');
        }
            var rp="";
            if (document.getElementById('RecipePhotos').value.length < 4) {
                if($('#PreviewPhoto').attr('src')!='')
                    rp=$('#PreviewPhoto').attr('src');
                else
                    rp="";
            }
            else
                rp=document.getElementById('RecipePhotos').files[0];
                
                
if(ef==1)
{
$('#errbod').html(err);
$('#errorMod1').modal();
return;
}






      

            var rd=$('#RecipeReviewer').val();
            var chkarr=new Array()
            for (var i=0;i<chkcnt;i++){
                chkarr[i]=$('#checkboxCustom'+(i+1)).is(":checked");
            }
            var chk=JSON.stringify(chkarr);
            var step =stepsCount;
            var taArray=new Array();
            for (var i = 0; i <step; i++) {
                taArray[i]=$("#ta"+(i)).val();
            }
            var ta=JSON.stringify(taArray);
            var x=new XMLHttpRequest();
            x.onreadystatechange=function(){
                if (this.readyState==4&& this.status==200) {
                
                    alert(this.responseText);
                       $('#sec-to-show').load('RecipeView.php');
                }
            };

            var flag;
            if (EditorCopy01==0)
            {
                flag=5;
            }
            else
                flag =3;


            var formData = new FormData();
            formData.append('rp',rp);
            x.open('POST','response.php?nm='+nm+'&wt='+wt+'&ft='+ft+'&en='+en+'&ca='+ca+'&pr='+pr+'&fb='+fb+'&wa='+wa+'&unt='+unt+'&rp='+rp+'&rd='+rd+'&chk='+chk+'&step='+step+'&ta='+ta+'&flag='+flag+'&Rid='+RId,true);


_progress = document.getElementById('prog');

x.upload.addEventListener('progress', function(e){
    _progress.style.width = Math.ceil(e.loaded/e.total) * 100 + '%';
}, false);

            x.send(formData);
        }

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#PreviewPhoto').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#RecipePhotos").change(function(){
            readURL(this);
        });

        $("#csvUp").change(function(){
            var x=new XMLHttpRequest();
            x.onreadystatechange=function(){
                if (this.readyState==4&& this.status==200) {
                    var a = JSON.parse(this.responseText);
                    alert(a[0]);
                    if(a[1]=="true"){

                        $('#downStep')[0].click();
                    }
                }
            };

            csv=document.getElementById('csvUp').files[0];
            var formData = new FormData();
            formData.append('csv',csv);
            x.open('POST','response.php?flag=7',true);



            x.send(formData);



        });


        $('#Upstep').click(function(){

            $('#csvStepUp')[0].click();
        });

        $('#csvStepUp').change(function(){
            var x=new XMLHttpRequest();
            x.onreadystatechange=function(){
                if (this.readyState==4&& this.status==200) {
                    alert(this.responseText);
                }
            }


            csv=document.getElementById('csvStepUp').files[0];
            var formData = new FormData();
            formData.append('csv',csv);
            x.open('POST','response.php?flag=9',true);

            x.send(formData);


        });


$('input[type="date"]').click(function(){
alert('sx');
});

    </script>




