<?php
$a=$_REQUEST['rid'];
echo $a;
?>