<?php


//connection to database
session_start();

	if(isset($_SESSION['userid'])){
	
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";
 $conn = mysqli_connect($servername, $username, $password, $dbname);
   if (!$conn) {
      die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
  }
  
}
else
	 echo "<script>window.location.href='login.html' </script>";
	

?>


<?php
//functions.php Update Query


global $conn;
$query = "SELECT * FROM hDietician_Enrollment";

$result = mysqli_query($conn, $query);

if(!$result){
die("query FAILED".mysqli_error());
}

while($row = mysqli_fetch_assoc($result)){
    $id = $row['Dt_Email'];
 
    }









?>


<style>
input[type="date" i], input[type="datetime-local" i], input[type="month" i], input[type="time" i], input[type="week" i]{
  color: transparent;

}

input[type="date" i]:focus{
  color: black;

}
</style>



<!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                
                <!-- Form Elements -->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                      <div class="dropdown">
                        <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Dietician Signup Form</h3>
                    </div>
                    <div class="card-body">
                      <form class="form-horizontal">
                       
                        <div class="line"> </div>
                        <div class="row">
                         <div class="col-sm-1"></div>
                          <div class="col-sm-10">
                            <div class="form-group-material">
                              <input id="register-username" type="text" name="registerName" required class="input-material">
                              <label for="register-username" class="label-material">Name</label>
                            </div>
                            

                              <div class="form-group-material">
                              <input id="register-address" type="text" name="registerAddress" required class="input-material">
                              <label for="register-address" class="label-material">Address</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-state" type="text" name="registerState" required class="input-material">
                              <label for="register-state" class="label-material">State</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-city" type="text" name="registerCity" required class="input-material">
                              <label for="register-city" class="label-material">City</label>
                            </div>

                                <div class="form-group-material">
                              <input id="register-phno" type="number" name="registerPhno" required class="input-material">
                              <label for="register-phno" class="label-material">Phone no.</label>
                            </div>


                            <div class="form-group-material">
                              <input id="register-alt-phno" type="number" name="registerAltPhno" required class="input-material">
                              <label for="register-alt-phno" class="label-material">Alternate Phone no.</label>
                            </div>

                              <div class="form-group-material">
                              <input id="register-email" type="email" name="registerEmail" required class="input-material">
                              <label for="register-email" class="label-material">Email   </label>
                            </div>


                            <div class="form-group-material">
                              <input id="register-from-date" type="date" name="registerFromDate" required class="input-material">
                              <label for="register-from-date" class="label-material">From Date     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-to-date" type="date" name="registerToDate" required class="input-material">
                              <label for="register-to-date" class="label-material">To Date     </label>
                            </div>

                            

                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Type</label>
                         <div class="col-sm-9  select">
                            <select id="register-type" multiple="" class="form-control">
                              <option value="Salaried">Salaried</option>
                              <option value="Contractual">Contractual</option>
                            </select>
                          </div>
                        </div>

                        <div class="form-group-material">
                              <input id="register-yrs-exp" type="number" name="registerYrsExp" required class="input-material">
                              <label for="register-yrs-exp" class="label-material">Years of Experience</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-Salary" type="number" name="registerSalary" required class="input-material">
                              <label for="register-Salary" class="label-material">Salary</label>
                            </div>

                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Designation</label>
                         <div class="col-sm-9  select">
                            <select id="register-designation" multiple="" class="form-control">
                              <option value="juniorDietician">Junior</option>
                              <option value="seniorDietician">Senior</option>
                              <option value="consultantDietician">Consultant</option>
                            </select>
                          </div>
                        </div>

                         

                             <div class="form-group row">
                          <label for="fileInput" class="col-sm-3 form-control-label lab">Photo</label>
                          <div class="col-sm-9">
                            <input id="fileInput" type="file" class="form-control-file">
                          </div>
                        </div>

                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Status</label>
                         <div class="col-sm-9  select">
                            <select id="register-status" multiple="" class="form-control">
                              <option value="0">No Access</option>
                              <option value="1">Access</option>
                            </select>
                          </div>
                        </div>

                         <div class="form-group-material">
                              <input id="register-created-by" type="text" name="registerCreatedBy" required class="input-material">
                              <label for="register-created-by" class="label-material">Created By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-created-date" type="date" name="registerCreatedDate" required class="input-material">
                              <label for="register-created-date" class="label-material">Created Date     </label>
                            </div>

                             <div class="form-group-material">
                              <input id="register-modified-by" type="text" name="registerModifiedBy" required class="input-material">
                              <label for="register-modified-by" class="label-material">Modified By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-modified-date" type="date" name="registerModifiedDate" required class="input-material">
                              <label for="register-modified-date" class="label-material">Modified Date     </label>
                            </div>

                            <div class="form-group-material">
                              <input name="submit" id="register-button" type="button" onclick="sub()"  name="registerButton"  class="input-material btn " value="Update" style="    width: 50%;
  position: relative;
    left: 50%;
    transform: translate(-50%,0);">
                            </div>


                          </div>
                           <div class="col-sm-1"></div>
                        </div>
                        <div class="line"></div>
                        
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <script>
          
                 
    var materialInputs = $('input.input-material');

    // activate labels for prefilled values
    materialInputs.filter(function() { return $(this).val() !== ""; }).siblings('.label-material').addClass('active');

    // move label on focus
    materialInputs.on('focus', function () {
        $(this).siblings('.label-material').addClass('active');
    });

    // remove/keep label on blur
    materialInputs.on('blur', function () {
        $(this).siblings('.label-material').removeClass('active');

        if ($(this).val() !== '') {
            $(this).siblings('.label-material').addClass('active');
        } else {
            $(this).siblings('.label-material').removeClass('active');
        }
    });
    
    

          
          </script>