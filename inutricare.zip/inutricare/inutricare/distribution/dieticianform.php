<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bootstrap Material Admin by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]
      -->
      <style type="text/css">
      

input[type="date" i], input[type="datetime-local" i], input[type="month" i], input[type="time" i], input[type="week" i]{
  color: transparent;

}

input[type="date" i]:focus{
  color: black;

}


.lab{
    color: #aaa;
    font-weight: 300;
        font-size: 1rem;
}

      </style>
  </head>
  <body>
    <div class="page">
      <!-- Main Navbar-->
      <header class="header">
        <nav class="navbar">
          <!-- Search Box-->
          <div class="search-box">
            <button class="dismiss"><i class="icon-close"></i></button>
            <form id="searchForm" action="#" role="search">
              <input type="search" placeholder="What are you looking for..." class="form-control">
            </form>
          </div>
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <!-- Navbar Header-->
              <div class="navbar-header">
                <!-- Navbar Brand --><a href="index.html" class="navbar-brand d-none d-sm-inline-block">
                  <div class="brand-text d-none d-lg-inline-block"><span>Bootstrap </span><strong>Dashboard</strong></div>
                  <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>BD</strong></div></a>
                <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
              </div>
              <!-- Navbar Menu -->
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <!-- Search-->
                <li class="nav-item d-flex align-items-center"><a id="search" href="#"><i class="icon-search"></i></a></li>
                <!-- Notifications-->
                <li class="nav-item dropdown"> <a id="notifications" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link"><i class="fa fa-bell-o"></i><span class="badge bg-red badge-corner">12</span></a>
                  <ul aria-labelledby="notifications" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-envelope bg-green"></i>You have 6 new messages </div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-twitter bg-blue"></i>You have 2 followers</div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-upload bg-orange"></i>Server Rebooted</div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-twitter bg-blue"></i>You have 2 followers</div>
                          <div class="notification-time"><small>10 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item all-notifications text-center"> <strong>view all notifications                                            </strong></a></li>
                  </ul>
                </li>
                <!-- Messages                        -->
                <li class="nav-item dropdown"> <a id="messages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link"><i class="fa fa-envelope-o"></i><span class="badge bg-orange badge-corner">10</span></a>
                  <ul aria-labelledby="notifications" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Jason Doe</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-2.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Frank Williams</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-3.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Ashley Wood</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item all-notifications text-center"> <strong>Read all messages   </strong></a></li>
                  </ul>
                </li>
                <!-- Languages dropdown    -->
                <li class="nav-item dropdown"><a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle"><img src="img/flags/16/GB.png" alt="English"><span class="d-none d-sm-inline-block">English</span></a>
                  <ul aria-labelledby="languages" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item"> <img src="img/flags/16/DE.png" alt="English" class="mr-2">German</a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> <img src="img/flags/16/FR.png" alt="English" class="mr-2">French                                         </a></li>
                  </ul>
                </li>
                <!-- Logout    -->
                <li class="nav-item"><a href="login.html" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="page-content d-flex align-items-stretch"> 
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4">Admin</h1>
              <p></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
                    <li><a href="index.html"> <i class="icon-home"></i>Home </a></li>
                    <li><a href="tables.html"> <i class="icon-grid"></i>Tables </a></li>
                    <li><a href="charts.html"> <i class="fa fa-bar-chart"></i>Charts </a></li>
                    <li class="active"><a href="forms.html"> <i class="icon-padnote"></i>Forms </a></li>
                    <li><a href="#exampledropdownDropdown" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Example dropdown </a>
                      <ul id="exampledropdownDropdown" class="collapse list-unstyled ">
                        <li><a href="#">Page</a></li>
                        <li><a href="#">Page</a></li>
                        <li><a href="#">Page</a></li>
                      </ul>
                    </li>
                    <li><a href="login.html"> <i class="icon-interface-windows"></i>Login page </a></li>
          </ul><span class="heading">Extras</span>
          <ul class="list-unstyled">
            <li> <a href="#"> <i class="icon-flask"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-screen"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-mail"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-picture"></i>Demo </a></li>
          </ul>
        </nav>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Forms</h2>
            </div>
          </header>
          <!-- Breadcrumb-->
          <div class="breadcrumb-holder container-fluid">
            <ul class="breadcrumb">
              <li class="breadcrumb-item"><a href="index.html">Home</a></li>
              <li class="breadcrumb-item active">Forms            </li>
            </ul>
          </div>
          <!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                
                <!-- Form Elements -->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                      <div class="dropdown">
                        <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Dietician Signup Form</h3>
                    </div>
                    <div class="card-body">
                      <form class="form-horizontal">
                       
                        <div class="line"> </div>
                        <div class="row">
                         <div class="col-sm-1"></div>
                          <div class="col-sm-10">
                            <div class="form-group-material">
                              <input id="register-username" type="text" name="registerName" required class="input-material">
                              <label for="register-username" class="label-material">Name</label>
                            </div>
                            

                              <div class="form-group-material">
                              <input id="register-address" type="text" name="registerAddress" required class="input-material">
                              <label for="register-address" class="label-material">Address</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-state" type="text" name="registerState" required class="input-material">
                              <label for="register-state" class="label-material">State</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-city" type="text" name="registerCity" required class="input-material">
                              <label for="register-city" class="label-material">City</label>
                            </div>

                                <div class="form-group-material">
                              <input id="register-phno" type="number" name="registerPhno" required class="input-material">
                              <label for="register-phno" class="label-material">Phone no.</label>
                            </div>


                            <div class="form-group-material">
                              <input id="register-alt-phno" type="number" name="registerAltPhno" required class="input-material">
                              <label for="register-alt-phno" class="label-material">Alternate Phone no.</label>
                            </div>

                              <div class="form-group-material">
                              <input id="register-email" type="email" name="registerEmail" required class="input-material">
                              <label for="register-email" class="label-material">Email   </label>
                            </div>


                            <div class="form-group-material">
                              <input id="register-from-date" type="date" name="registerFromDate" required class="input-material">
                              <label for="register-from-date" class="label-material">From Date     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-to-date" type="date" name="registerToDate" required class="input-material">
                              <label for="register-to-date" class="label-material">To Date     </label>
                            </div>

                            

                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Type</label>
                         <div class="col-sm-9  select">
                            <select id="register-type" multiple="" class="form-control">
                              <option value="Salaried">Salaried</option>
                              <option value="Contractual">Contractual</option>
                            </select>
                          </div>
                        </div>

                        <div class="form-group-material">
                              <input id="register-yrs-exp" type="number" name="registerYrsExp" required class="input-material">
                              <label for="register-yrs-exp" class="label-material">Years of Experience</label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-Salary" type="number" name="registerSalary" required class="input-material">
                              <label for="register-Salary" class="label-material">Salary</label>
                            </div>

                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Designation</label>
                         <div class="col-sm-9  select">
                            <select id="register-designation" multiple="" class="form-control">
                              <option value="juniorDietician">Junior</option>
                              <option value="seniorDietician">Senior</option>
                              <option value="consultantDietician">Consultant</option>
                            </select>
                          </div>
                        </div>

                         

                             <div class="form-group row">
                          <label for="fileInput" class="col-sm-3 form-control-label lab">Photo</label>
                          <div class="col-sm-9">
                            <input id="fileInput" type="file" class="form-control-file">
                          </div>
                        </div>

                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Status</label>
                         <div class="col-sm-9  select">
                            <select id="register-status" multiple="" class="form-control">
                              <option value="0">No Access</option>
                              <option value="1">Access</option>
                            </select>
                          </div>
                        </div>

                         <div class="form-group-material">
                              <input id="register-created-by" type="text" name="registerCreatedBy" required class="input-material">
                              <label for="register-created-by" class="label-material">Created By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-created-date" type="date" name="registerCreatedDate" required class="input-material">
                              <label for="register-created-date" class="label-material">Created Date     </label>
                            </div>

                             <div class="form-group-material">
                              <input id="register-modified-by" type="text" name="registerModifiedBy" required class="input-material">
                              <label for="register-modified-by" class="label-material">Modified By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-modified-date" type="date" name="registerModifiedDate" required class="input-material">
                              <label for="register-modified-date" class="label-material">Modified Date     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-button" type="button" onclick="sub()"  name="registerButton"  class="input-material btn " value="Register" style="    width: 50%;
  position: relative;
    left: 50%;
    transform: translate(-50%,0);">
                            </div>


                          </div>
                           <div class="col-sm-1"></div>
                        </div>
                        <div class="line"></div>
                        
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Your company &copy; 2017-2019</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a href="https://bootstrapious.com/admin-templates" class="external">Bootstrapious</a></p>
                  <!-- Please do not remove the backlink to us unless you support further theme's development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    

    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
    
    
        <script>
        
        function sub(){
       var formData = new FormData();
  formData.append('name',$('#register-username').val());
  formData.append('addr',$('#register-address').val());
  formData.append('state',$('#register-state').val());
  formData.append('city',$('#register-city').val());
  formData.append('phno',$('#register-phno').val());
  formData.append('altphno',$('#register-alt-phno').val());
  formData.append('email',$('#register-email').val());
  formData.append('fdate',$('#register-from-date').val());
  formData.append('tdate',$('#register-to-date').val());
  formData.append('type',$('#register-type').val());
  formData.append('yexp',$('#register-yrs-exp').val());
  formData.append('salary',$('#register-Salary').val());
  formData.append('design',$('#register-designation').val());
  formData.append('photo',document.getElementById('fileInput').files[0]);  

  formData.append('status',$('#register-status').val());
  formData.append('createdby',$('#register-created-by').val());
  formData.append('createddt',$('#register-created-date').val());
 formData.append('modifiedby',$('#register-modified-by').val());
  formData.append('modifieddt',$('#register-modified-date').val());
  formData.append('flag','1');
  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'response.php', true);
  xhr.onload = function(e) {

    if (this.status == 200) {
   
  alert(this.responseText);
     
     
    }
   };

  xhr.send(formData);


}

$("input[type='date' i]").on("change", function() {
    $(this).css('color','black');
   
});

    </script>
  
    
  </body>
</html>