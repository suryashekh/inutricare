<div class="d-flex">
 <div style="" class="mb-3 mt-3 d-flex">
   <button id="plusAddPlanBtn" onclick="$('#modalAddPlan').modal();" style="font-size: 25px;font-weight: 600; border-radius: 50%; " class="has-shadow btn btn-primary"><span class="fas fa-plus"></span></button>
   <div id="showPlanMsg"  >
     Add New Plan
   </div>
 </div>
  <div id="alert1" style="padding-left:15px; width:100%;">

    <div class="mt-3 mb-3 alert  alert-dismissible fade " id="alrt">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <div id='alrtContent'><strong>Success!</strong> Meal Added!!.
      </div>
  </div>

  </div>

  </div>
  <!-- <button class="btn btn-primary" id="bmat" ><i class="fas fa-plus"></i></button>-->
<div  style=" background-color:white; box-shadow:2px 2px 2px lightgray; padding: 10px;" >
<div id="plans" class="text-center">

</div>


</div>