<?php


//connection to database
session_start();

  if(isset($_SESSION['userid'])){
  
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";

 $conn = mysqli_connect($servername, $username, $password, $dbname);
   if (!$conn) {
      die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
  }
  
?>


<style>
input[type="date" i], input[type="datetime-local" i], input[type="month" i], input[type="time" i], input[type="week" i]{
  color: transparent;

}

input[type="date" i]:active{
  color: black;

}
.line{
  margin:5px 0px !important;
}
</style>



<!-- Forms Section-->
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
                <!-- Basic Form-->
                
                <!-- Form Elements -->
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                      <div class="dropdown" style="display:none;">
                        <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                        <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" class="dropdown-item remove"> <i class="fa fa-times"></i>Close</a><a href="#" class="dropdown-item edit"> <i class="fa fa-gear"></i>Edit</a></div>
                      </div>
                    </div>
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Member Signup Form</h3>
                    </div>
                    <div class="card-body">
                     
                       
                        
                        <div class="row">
                          
                         <div class="col-sm-1"></div>
                          <div class="col-sm-10">
                            

                          <div class="row" style="display:flex; justify-content:center; ">
                          <h2 class="h4 has-shadow"  style="width:100%;padding: 15px 0px;" onclick="$('#aone').slideToggle();">Member Demographics Details </h2> 
                          </div>
                      <div class="has-shadow" style="padding:7px;" id="aone"> 

                           <div class="form-group-material">
                              <input id="register-AssocId" type="text" name="registerAssocName" required class="input-material">
                              <label for="register-AssocId" class="label-material">Associate Id (Optional)</label>
                            </div>
                          
                            <div class="form-group-material">
                              <input id="register-username" type="text" name="registerName" required class="input-material">
                              <label for="register-username" class="label-material">Name</label>
                            </div>
                            

                    
                            <div class="form-group-material">
                              <input id="register-age" type="number" name="registerAge" required class="input-material">
                              <label for="register-age" class="label-material">Age</label>
                            </div>
                            
                            
                            
                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Gender</label>
                         <div class="col-sm-9  select">
                            <select id="register-gender"  class="form-control">
                              <option value="Male">Male</option>
                              <option value="Female">Female</option>
                               <option value="Others">Others</option>
                            </select>
                          </div>
                        </div>
                            
                            
                               <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Status</label>
                         <div class="col-sm-9  select">
                            <select id="register-status" disabled  class="form-control">
                              <option value="active">Active</option>
                              <option value="inactive">Inactive</option>
                               <option value="enrolled">Enrolled</option>
                            </select>
                          </div>
                        </div>
                              
                              
                            <div class="form-group-material">
                              <input id="register-pno" type="number" name="registerpno" required class="input-material">
                              <label for="register-pno" class="label-material">Phone No.</label>
                            </div>
                                     
                            <div class="form-group-material">
                              <input id="register-apno" type="number" name="registerapno" required class="input-material">
                              <label for="register-apno" class="label-material">Alternate Phone No. (Optional)</label>
                            </div>
                              
                               <div class="form-group-material">
                              <input id="register-addr" type="text" name="registeraddr" required class="input-material">
                              <label for="register-addr" class="label-material">Address</label>
                            </div>
                               <div class="form-group-material">
                              <input id="register-city" type="text" name="registercity" required class="input-material">
                              <label for="register-city" class="label-material">City</label>
                            </div>
                             <div class="form-group-material">
                              <input id="register-state" type="text" name="registerstate" required class="input-material">
                              <label for="register-state" class="label-material">State</label>
                            </div>
                            
                            
                         
                              <div class="form-group-material">
                              <input id="register-email" type="email" name="registerEmail" required class="input-material">
                              <label for="register-email" class="label-material">Email   </label>
                            </div>

                            <div class="form-group row">
                          <label class="col-sm-3 form-control-label lab">Assigned Dietician</label>
                         <div class="col-sm-9  select">
                            <select id="register-Assigned-Dietician" class="form-control">
                             <?php
                                $q="Select * from hDietician_Enrollment";
                                $rs=mysqli_query($conn,$q);
                                while($row=mysqli_fetch_assoc($rs)){
                                echo "<option value='".$row['Dt_AuthID']."'>".$row['Dt_Name']."</option>";
                              }

                             ?>
                            </select>
                          </div>
                        </div>

                         
                  <!--   

                         <div class="form-group-material">
                              <input id="register-created-by" type="text" name="registerCreatedBy" required class="input-material">
                              <label for="register-created-by" class="label-material">Created By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-created-date" type="date" name="registerCreatedDate" required class="input-material">
                              <label for="register-created-date" class="label-material">Created Date     </label>
                            </div>

                             <div class="form-group-material">
                              <input id="register-modified-by" type="text" name="registerModifiedBy" required class="input-material">
                              <label for="register-modified-by" class="label-material">Modified By     </label>
                            </div>

                            <div class="form-group-material">
                              <input id="register-modified-date" type="date" name="registerModifiedDate" required class="input-material">
                              <label for="register-modified-date" class="label-material">Modified Date     </label>
                            </div>
                        -->
                            </div>
                       
                             <div class="line"> </div>
                        
                        <div class="row" style="justify-content:center; ">
                        <h2 class="h4 has-shadow"  style="padding: 15px 0px; width:100%;"  onclick="$('#atwo').slideToggle();">Member Health Condition Details </h2> 
                        </div>
                        
                      
                        
                         
                          <div class="has-shadow" style="display: none;padding:7px;" id="atwo"> 
                            <div>
                              <div id="tHealthCon">
                       <!--         <div style='display:flex;justify-content:space-between'>
                                     <div class="form-group-material">
                                      <input id="rHDate1" type="date"  required class="input-material">
                                      <label for="rHDate1" class="label-material">Measure Date</label>
                                    </div>
                                  <div class="form-group row">
                                    <label class="col-sm-3 form-control-label lab"> Type</label>
                                  <div class="col-sm-9  select">
                                      <select id="rHType1"  class="form-control mtype">
                                       <?php
                                $q="SELECT * FROM hGen_Health_Demo ";
                                $rs=mysqli_query($conn,$q);
                                $sel="";
                                while($row=mysqli_fetch_assoc($rs)){
                                $sel.="<option value='".$row['measure_type']."'>".$row['description']."</option>";
                              }
                                  echo $sel;
                             ?>
                                      </select>
                                   </div>
                                  </div>
                                  
                                       <div class="form-group-material">
                                          <input id="rHVal1" type="text" name="rHVal" required class="input-material">
                                          <label for="rHVal1" class="label-material">Measure Value</label>
                                      </div>
                                      </div>-->
                                </div>
                               <button class="btn btn-primary" style="margin-top: 30px;" onclick="addHParam()">Add</button>
                            
                                <?php

                                            if(isset($_SESSION['memupflag'])&&$_SESSION['memupflag']==1)
                                            {
                                            $ar=$_SESSION['memuparr'];
                                             
                                ?>    <h3 class="h3" style="text-align:center">History</h3>
                                                    <div class="table-responsive-sm" style="width: 100%; margin: 30px 0px;">
                                    <table class="table table-hover " style="text-align:center;">
                                      <thead>
                                            <tr>
                                              <th>Date</th>
                                              <th>Type</th>
                                              <th>Value</th>
                                            </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $sql="SELECT `measure_date`,`measure_type`,`measure_val` FROM `hMem_Health_Demo` WHERE member_id='{$ar[0][0]['memuserid']}' and id in (SELECT max(id) FROM hMem_Health_Demo where `member_id`='{$ar[0][0]['memuserid']}' GROUP by `measure_type`)";
                                        $rs=mysqli_query($conn,$sql);
                                        while ($r=mysqli_fetch_assoc($rs)) {
                                          echo "<tr><td>{$r['measure_date']}</td><td>{$r['measure_type']}</td><td>{$r['measure_val']}</td></tr>";
                                        }
                      ?>
                                      </tbody>
                                    </table>
          
                                </div>
                                <?php
                                  }
                                ?>
                                                    
                            </div>
                            <script type="text/javascript">
                              var sel= "<?php echo $sel; ?>";

                            
                            </script>
                            
                            
                 <!--           <div class="form-group-material">
                              <input id="register-HDate" type="date" name="registerHDate" required class="input-material">
                              <label for="register-HDate" class="label-material">Record Date</label>
                            </div>
                          
                            

                        <div class="row">
                            <div class="form-group-material col-sm-6">
                              <input id="register-Height" type="number" name="registerHeight" required class="input-material">
                              <label for="register-Height" style="left:20px" class="label-material">Height</label>
                            </div>
                            
                            <div class="form-group-material col-sm-6">
                              <input id="register-Weight" type="number" name="registerWeight" required class="input-material">
                              <label for="register-Weight" style="left:20px"  class="label-material">Weight</label>
                            </div>
                         </div>
                            
                           <div class="row">
                            <div class="form-group-material col-sm-6">
                              <input id="register-Waist" type="number" name="registerWaist" required class="input-material">
                              <label for="register-Waist" style="left:20px" class="label-material">Waist</label>
                            </div>
                            
                             <div class="form-group-material col-sm-6">
                              <input id="register-Chest" type="number" name="registerChest" required class="input-material">
                              <label for="register-Chest"  style="left:20px" class="label-material">Chest</label>
                            </div>
                            
                            </div>

                              <div class="row">
                            <div class="form-group-material col-sm-6">
                              <input id="register-SugarLevel" type="number" name="registerSugarLevel" required class="input-material">
                              <label for="register-SugarLevel" style="left:20px" class="label-material">Sugar Level</label>
                            </div>
                            
                             <div class="form-group-material col-sm-6">
                              <input id="register-BloodPressure" type="number" name="registerBloodPressure" required class="input-material">
                              <label for="register-BloodPressure" style="left:20px" class="label-material">Blood Pressure</label>
                            </div>
                            </div> 
                            
                              <div class="row">
                            <div class="form-group-material col-sm-6">
                              <input id="register-LipidProfile" type="number" name="registerLipidProfile" required class="input-material">
                              <label for="register-LipidProfile" style="left:20px" class="label-material">Lipid Profile</label>
                            </div>
                            
                            
                              <div class="form-group-material col-sm-6">
                              <input id="register-Tyroid" type="number" name="registerTyroid" required class="input-material">
                              <label for="register-Tyroid" style="left:20px" class="label-material">Tyroid</label>
                            </div>
                            </div>
                         
    
                            <div class="form-group-material">
                              <input id="register-taken-by" type="text" name="registerTakenBy" required class="input-material">
                              <label for="register-taken-by" class="label-material">Taken By     </label>
                            </div>
                       
                         <div class="row">

                         <div class="form-group-material col-sm-6">
                              <input id="register-Hcreated-by" type="text" name="registerHCreatedBy" required class="input-material">
                              <label for="register-Hcreated-by" style="left:20px" class="label-material">Created By     </label>
                            </div>
                           
                            <div class="form-group-material col-sm-6">
                              <input id="register-Hcreated-date" type="date" name="registerHCreatedDate" required class="input-material">
                              <label for="register-Hcreated-date" style="left:20px" class="label-material">Created Date     </label>
                            </div>
                            </div>
                       <div class="row">
                             <div class="form-group-material col-sm-6">
                              <input id="register-Hmodified-by" type="text" name="registerHModifiedBy" required class="input-material">
                              <label for="register-Hmodified-by" style="left:20px" class="label-material">Modified By     </label>
                            </div>
                             

                            <div class="form-group-material col-sm-6">
                              <input id="register-Hmodified-date" type="date" name="registerHModifiedDate" required class="input-material">
                              <label for="register-Hmodified-date" style="left:20px" class="label-material">Modified Date     </label>
                            </div>
            </div>
          -->
 </div>
 <div class="line"></div>

                       <div class="row"  style="justify-content:center; ">
                        <h2 class="h4 has-shadow"  style=" width:100%;padding: 15px 0px;" onclick="$('#athree').slideToggle();" >Member Dietary Preferences </h2> 
                        </div> 
                        
                        <div class="has-shadow" style="display: none;padding:7px;" id="athree"> 
                           <div class="row" style="  padding: 30px 0;" >
                    <?php
                    $chkcnt=0;
                     $sql="select * from hGen_Diet_Pref";
  $rs=mysqli_query($conn,$sql);

                    while($row=mysqli_fetch_assoc($rs))
                    { $chkcnt++;
                    ?>
                    
                     <div style="margin:5px 20px;">
                              <input name="Dpreff[]" id="checkboxH<?php echo $row['Dp_Id'];?>" type="checkbox" value="" class="checkbox-template">
                              <label for="checkboxH<?php echo $row['Dp_Id'];?>"><?php echo $row['Dp_name']; ?></label>
                            </div>
                      
                    <?php
                    }
                    
                    echo "<script> var chkcnt=".$chkcnt."; </script>";
                    ?>
                               </div>
</div>
<div class="line"></div>
                   
                       <div class="row" style="justify-content:center; ">
                        <h2 class="h4 has-shadow"  style="width:100%;padding: 15px 0px;" onclick="$('#afour').slideToggle();">Member Allergies 
</h2> </div>
<div class="has-shadow" style="display: none;padding:7px;" id="afour"> 
                       
                        
                        
                           <div class="row" style="  padding: 30px 0;" >
                    <?php
                    $chkcnt1=0;
                     $sql="select * from hGen_Allergiesf";
  $rs=mysqli_query($conn,$sql);

                    while($row=mysqli_fetch_assoc($rs))
                    { $chkcnt1++;
                    ?>
                    
                     <div style="margin:5px 20px;">
                              <input name="allergy[]" id="checkboxH1<?php echo $row['Al_Id'];?>" type="checkbox" value="" class="checkbox-template">
                              <label for="checkboxH1<?php echo $row['Al_Id'];?>"><?php echo $row['Al_name'];?></label>
                            </div>
                      
                    <?php
                    }
                    
                    echo "<script> var chkcnt1=".$chkcnt1."; </script>";
                    ?>
                               </div>
</div>
 <div class="line"></div>

                       <div class="row"  style="justify-content:center; ">
                        <h2 class="h4 has-shadow"  style=" width:100%;padding: 15px 0px;" onclick="$('#afive').slideToggle();" >Member Notes</h2> 
                        </div> 
                        
                        <div class="has-shadow" style="display: none;padding:7px;" id="afive"> 
                           <div class="row" style="  padding: 30px 0;" >
                                <div class="form-group row" style="diplay:flex; justify-content:space-between;">
                                <div class="form-group-material"> <input id="notedate" type="date" name="registernoteDate" required class="input-material">
                              <label for="notedate" style="left:20px" class="label-material">Note Date</label>
                              </div>   
                              <div class="col-sm-9" >
                                    <textarea  class="form-control" id="note" cols="80">
                                      
                                    </textarea>
                                   </div>
                                  </div>
                    
                                <?php

                                            if(isset($_SESSION['memupflag'])&&$_SESSION['memupflag']==1)
                                            {
                                            $ar=$_SESSION['memuparr'];
                                             
                                ?>    <h3 class="h3" style=" width:100%;text-align:center">History</h3>
                                                    <div class="table-responsive-sm" style="width: 100%; margin: 30px 0px;">
                                    <table class="table table-hover " style="text-align:center;">
                                      <thead>
                                            <tr>
                                              <th>Date</th>
                                              <th>Note</th>
                                             
                                            </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                
                                        $sql="SELECT `Mb_date`,`Mb_Note` FROM `hMember_Notes` where `Mb_Id`='{$ar[0][0]['Mb_ID']}' limit 3";
                                        $rs=mysqli_query($conn,$sql);
                                        while ($r=mysqli_fetch_assoc($rs)) {
                                          echo "<tr><td>{$r['Mb_date']}</td><td>{$r['Mb_Note']}</td></tr>";
                                        }
                      ?>
                                      </tbody>
                                    </table>
          
                                </div>
                                <?php
                                  }
                                ?>
                            
                               </div>
</div>
                            <div class="form-group-material">
                              <input name="submit" id="register-button" type="button" onclick="subMember()"  name="registerButton"  class="input-material btn mt-5" value="Submit Member" style="    width: 50%;
  position: relative;
    left: 50%;
    transform: translate(-50%,0);">
                            </div>


                         
                           
                 
                        </div>
                        <div class="col-sm-1"></div>
                         </div>
                        
                   
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
                                <!-- The Modal -->
<div class="modal" id="errorMod">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Error Submiting Member</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" id="errbod">
        Modal body..
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
                                
          <script>
          

    
    
    $("input[type='date' i]").on("change", function() {
    $(this).css('color','black');
   
    });

function subMember(){
 
  var regex = new RegExp("^[a-zA-Z ]+$");

var err="",ef=0;

    var Aid=$('#register-AssocId').val();
    var nm=$('#register-username').val();

    if (!regex.test(nm.trim())||nm.trim().length==0) {
        err+="Invalid Characters in Name field, ";
        ef=1;
    $('#register-username').css('border','2px solid red');
    }else{
      $('#register-username').css('border','');
    }

        
var age=$('#register-age').val();
          if((isNaN(age))||(age.trim().length==0))
                    {
            $('#register-age').css('border','2px solid red');
                    err+="Invalid Age, ";
                     ef=1;
                    }else{
      $('#register-age').css('border','');
    }

    var gen=$('#register-gender').val();
    var sts=$('#register-status').val();
    var email=$('#register-email').val();
if((email.trim().length==0)||!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
                    {
$('#register-email').css('border','2px solid red');
                    err+="Invalid Email Id, ";
                   ef=1;
                    }else{
      $('#register-email').css('border','');
    }
 
    var asDiet=$('#register-Assigned-Dietician').val();
 if($('#register-pno').val().trim().length==0||$('#register-apno').val().trim().length!=10)
                    {
                   err+="Invalid Phone Value, ";
                     ef=1;
            $('#register-pno').css('border','2px solid red');
                    }else{
      $('#register-pno').css('border','');
    }
     if($('#register-apno').val().trim().length!=0&&$('#register-apno').val().trim().length!=10)
                    {
                   err+="Invalid Alternate Phone Value, ";
                     ef=1;
            $('#register-apno').css('border','2px solid red');
                    }else{
      $('#register-apno').css('border','');
    }


     if($('#register-addr').val().trim().length==0)
                    {
                   err+="Invalid Address Value, ";
                     ef=1;
            $('#register-addr').css('border','2px solid red');
                    }else{
      $('#register-addr').css('border','');
    }
     if($('#register-city').val().trim().length==0)
                    {
                   err+="Invalid City Value, ";
                     ef=1;
            $('#register-city').css('border','2px solid red');
                    }else{
      $('#register-city').css('border','');
    }
      if($('#register-state').val().trim().length==0)
                    {
                   err+="Invalid State Value, ";
                     ef=1;
            $('#register-state').css('border','2px solid red');
                    }else{
      $('#register-state').css('border','');
    }

var note=$('#note').val();
          if(note.trim().length!=0 && $('#notedate').val().length==0)
                    {
          
            $('#notedate').css('border','2px solid red');
                    err+="Invalid Note Date, ";
                     ef=1;
                    }else{
      $('#register-age').css('border','');
    }


  /*  var cb=$('#register-created-by').val();
    var cd=$('#register-created-date').val();
    var mb=$('#register-modified-by').val();
     var md=$('#register-modified-date').val();
    
    var rhd=$('#register-HDate').val();
    var rht=$('#register-Height').val();
    var rwt=$('#register-Weight').val();
    var rwa=$('#register-Waist').val();
    var rch=$('#register-Chest').val();
    var rsl=$('#register-SugarLevel').val();
    var rbp=$('#register-BloodPressure').val();
    var rlp=$('#register-LipidProfile').val();
    var rt=$('#register-Tyroid').val();
    var rtb=$('#register-taken-by').val();
    var rhcb=$('#register-Hcreated-by').val();
    var rhcd=$('#register-Hcreated-date').val();
    var rhmb=$('#register-Hmodified-by').val();
    var rhmd=$('#register-Hmodified-date').val();
   */ 
         var arrHealth=new Array();
         var x=0;
       for (var i=0;i<cntHparam;i++){
        arrHealth[x]=$('#rHDate'+(i+1)).val();
        arrHealth[x+1]=$('#rHType'+(i+1)).val();
        arrHealth[x+2]=$('#rHVal'+(i+1)).val();
                if( arrHealth[x].trim().length==0)
                    {
                $('#rHDate'+(i+1)).css('border','2px solid red');
                    err+=" Invalid Date for Member Health Condition, ";
                    ef=1;
                    }else{
      $('#rHDate'+(i+1)).css('border','');
    }
       
       if((isNaN(arrHealth[x+2]))||(arrHealth[x+2].trim().length==0))
                    {
        $('#rHVal'+(i+1)).css('border','2px solid red');
                    err+="Invalid Value for Member Health Condition, ";
                    ef=1;
            }else{
      $('#rHVal'+(i+1)).css('border','');
    }
       
        x+=3;
        }
if(ef!=0)
{

$('#errbod').html(err);
$('#errorMod').modal();
return;
}
       var arrH=JSON.stringify(arrHealth);   
    
        var chkarr=new Array();
       for (var i=0;i<chkcnt;i++){
        chkarr[i]=$('#checkboxH'+(i+1)).is(":checked");
        }
       var chk=JSON.stringify(chkarr);
       
        var chkarrAll=new Array();
       for (var i=0;i<chkcnt1;i++){
        chkarrAll[i]=$('#checkboxH1'+(i+1)).is(":checked");
        }
       var chkAll=JSON.stringify(chkarrAll);
       
       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
        if (this.readyState==4&& this.status==200) {
          alert(this.responseText);
           $('#sec-to-show').load('membersView.php');
        } 
       };
       
        var flag=10;
  
        
   
x.open('POST','response.php?Aid='+Aid+'&nm='+nm+'&age='+age+'&gen='+gen+'&sts='+sts+'&email='+email+'&asDiet='+asDiet+'&chk='+chk+'&chkAll='+chkAll+'&arrH='+arrH+'&note='+note.trim()+'&notedate='+$('#notedate').val().trim()+'&pno='+$('#register-pno ').val().trim()+'&apno='+$('#register-apno').val().trim()+'&addr='+$('#register-addr').val().trim()+'&state='+$('#register-state').val().trim()+'&city='+$('#register-city').val().trim()+'&flag='+flag,true);
       x.send();

      }


      $(function(){
material123();
});
function material123(){
 var materialInputs = $('input.input-material');

        // activate labels for prefilled values
        materialInputs.filter(function() { return $(this).val() !== ""; }).siblings('.label-material').addClass('active');

        // move label on focus
        materialInputs.on('focus', function () {
            $(this).siblings('.label-material').addClass('active');
        });

        // remove/keep label on blur
        materialInputs.on('blur', function () {
            $(this).siblings('.label-material').removeClass('active');

            if ($(this).val() !== '') {
                $(this).siblings('.label-material').addClass('active');
            } else {
                $(this).siblings('.label-material').removeClass('active');
            }
        });
}


        var cntHparam=0;
                              function addHParam(){
                                cntHparam++;
                                
                                  var str="<div style='display:flex;justify-content:space-between'> <div class='form-group-material'> <input id='rHDate"+cntHparam+"' onchange=this.style.color='black'; type='date'  required class='input-material date1'> <label for='rHDate"+cntHparam+"' class='label-material'>Measure Date</label> </div>  <div class='form-group row'> <label class='col-sm-3 form-control-label lab'> Type</label> <div class='col-sm-9 select'> <select id='rHType"+cntHparam+"' class='form-control mtype'> "+sel+"</select> </div> </div>  <div class='form-group-material'> <input id='rHVal"+cntHparam+"' type='text' name='rHVal' required class='input-material'> <label for='rHVal"+cntHparam+"' class='label-material'>Measure Value</label> </div></div> ";
                    $('#tHealthCon').append(str);
                        material123();
                              }
  
           $(".date1").on("click", function() {
           alert(123);
    $(this).css('color','black');
   
});

          </script>

<?php

if(isset($_SESSION['memupflag'])&&$_SESSION['memupflag']==1)
{
$ar=$_SESSION['memuparr'];
 ?>
<script>


  var memid='<?php echo $ar[0][0]['Mb_ID']; ?>';
   $('#register-AssocId').val('<? echo $ar[0][0]['Ast_AuthId']; ?>');
   $('#register-username').val('<? echo $ar[0][0]['Mb_Name']; ?>');
    $('#register-age').val('<? echo $ar[0][0]['Mb_Age']; ?>');
    $('#register-gender').val('<? echo $ar[0][0]['Mb_Gen']; ?>');
    $('#register-status').val('<? echo $ar[0][0]['Mb_Status']; ?>');
  $('#register-pno').val('<? echo $ar[0][0]['Phoneno']; ?>');
  $('#register-apno').val('<? echo $ar[0][0]['AltPhoneno']; ?>');
  $('#register-addr').val('<? echo $ar[0][0]['Address']; ?>');
  $('#register-state').val('<? echo $ar[0][0]['State']; ?>');
  $('#register-city').val('<? echo $ar[0][0]['City']; ?>');
    $('#register-email').val('<? echo $ar[0][0]['Mb_Email']; ?>');
    $('#register-Assigned-Dietician').val('<? echo $ar[0][0]['Dt_AuthID']; ?>');
var ch1=JSON.parse('<? echo $ar[1][0]['Mem_pref']; ?>');
var ch2=JSON.parse('<? echo $ar[1][0]['allergy_pref']; ?>');
//alert(ch1[0]);
  for (var i=0;i<chkcnt;i++){
  if(ch1[i]==true)
  { $('#checkboxH'+(i+1)).prop("checked","true");
  }
        }


       for (var i=0;i<chkcnt1;i++){
     if(ch2[i]==true)
       $('#checkboxH1'+(i+1)).prop("checked","true");
        }

$('#register-button').attr('value','Update Member');
$('#register-button').attr('onclick','updatemember()');


function updatemember(){
   var Aid=$('#register-AssocId').val();
    var nm=$('#register-username').val();
    var age=$('#register-age').val();
    var gen=$('#register-gender').val();
    var sts=$('#register-status').val();
    var pno=$('#register-pno').val();
    var apno=$('#register-apno').val();
    var addr=$('#register-addr').val();
    var state=$('#register-state').val();
    var city=$('#register-city').val();
    var email=$('#register-email').val();
    var asDiet=$('#register-Assigned-Dietician').val();

 var regex = new RegExp("^[a-zA-Z ]+$");

var err="",ef=0;

  

    if (!regex.test(nm.trim())||nm.trim().length==0) {
        err+="Invalid Characters in Name field, ";
        ef=1;
    $('#register-username').css('border','2px solid red');
    }else{
      $('#register-username').css('border','');
    }

        

          if((isNaN(age))||(age.trim().length==0))
                    {
            $('#register-age').css('border','2px solid red');
                    err+="Invalid Age, ";
                     ef=1;
                    }else{
      $('#register-age').css('border','');
    }

  
if((email.trim().length==0)||!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)))
                    {
$('#register-email').css('border','2px solid red');
                    err+="Invalid Email Id, ";
                   ef=1;
                    }else{
      $('#register-email').css('border','');
    }
 
   
 if($('#register-pno').val().trim().length==0||$('#register-apno').val().trim().length!=10)
                    {
                   err+="Invalid Phone Value, ";
                     ef=1;
            $('#register-pno').css('border','2px solid red');
                    }else{
      $('#register-pno').css('border','');
    }
     if($('#register-apno').val().trim().length!=0&&$('#register-apno').val().trim().length!=10)
                    {
                   err+="Invalid Alternate Phone Value, ";
                     ef=1;
            $('#register-apno').css('border','2px solid red');
                    }else{
      $('#register-apno').css('border','');
    }


     if($('#register-addr').val().trim().length==0)
                    {
                   err+="Invalid Address Value, ";
                     ef=1;
            $('#register-addr').css('border','2px solid red');
                    }else{
      $('#register-addr').css('border','');
    }
     if($('#register-city').val().trim().length==0)
                    {
                   err+="Invalid City Value, ";
                     ef=1;
            $('#register-city').css('border','2px solid red');
                    }else{
      $('#register-city').css('border','');
    }
      if($('#register-state').val().trim().length==0)
                    {
                   err+="Invalid State Value, ";
                     ef=1;
            $('#register-state').css('border','2px solid red');
                    }else{
      $('#register-state').css('border','');
    }

var note=$('#note').val();
          if(note.trim().length!=0 && $('#notedate').val().length==0)
                    {
          
            $('#notedate').css('border','2px solid red');
                    err+="Invalid Note Date, ";
                     ef=1;
                    }else{
      $('#register-age').css('border','');
    }




var notedate=$('#notedate').val();    


  var arrHealth=new Array();
         var x=0;
       for (var i=0;i<cntHparam;i++){
        arrHealth[x]=$('#rHDate'+(i+1)).val();
        arrHealth[x+1]=$('#rHType'+(i+1)).val();
        arrHealth[x+2]=$('#rHVal'+(i+1)).val();
                if( arrHealth[x].trim().length==0)
                    {
                $('#rHDate'+(i+1)).css('border','2px solid red');
                    err+=" Invalid Date for Member Health Condition, ";
                    ef=1;
                    }else{
      $('#rHDate'+(i+1)).css('border','');
    }
       
       if((isNaN(arrHealth[x+2]))||(arrHealth[x+2].trim().length==0))
                    {
        $('#rHVal'+(i+1)).css('border','2px solid red');
                    err+="Invalid Value for Member Health Condition, ";
                    ef=1;
            }else{
      $('#rHVal'+(i+1)).css('border','');
    }
       
        x+=3;
        }
if(ef!=0)
{

$('#errbod').html(err);
$('#errorMod').modal();
return;
}



 
       var arrH=JSON.stringify(arrHealth);   
    
        var chkarr=new Array();
       for (var i=0;i<chkcnt;i++){
        chkarr[i]=$('#checkboxH'+(i+1)).is(":checked");
        }
       var chk=JSON.stringify(chkarr);
       
        var chkarrAll=new Array();
       for (var i=0;i<chkcnt1;i++){
        chkarrAll[i]=$('#checkboxH1'+(i+1)).is(":checked");
        }
       var chkAll=JSON.stringify(chkarrAll);
       
       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
        if (this.readyState==4&& this.status==200) {
          alert(this.responseText);
           $('#sec-to-show').load('membersView.php');
        } 
       };
       
        var flag="updatememfinal";
  
        
   
x.open('POST','response.php?Aid='+Aid+'&nm='+nm+'&age='+age+'&gen='+gen+'&sts='+sts+'&email='+email+'&asDiet='+asDiet+'&chk='+chk+'&chkAll='+chkAll+'&arrH='+arrH+'&mid='+memid+'&note='+note.trim()+'&notedate='+notedate.trim()+'&pno='+pno.trim()+'&apno='+apno.trim()+'&addr='+addr.trim()+'&state='+state.trim()+'&city='+city.trim()+'&flag='+flag,true);

       x.send();

}

  /*  $('#register-created-by').val('<? echo $ar[0][0]['Created_By']; ?>');
    $('#register-created-date').val('<? echo $ar[0][0]['Created_Date']; ?>');
    $('#register-modified-by').val('<? echo $ar[0][0]['Modified_By']; ?>');
    $('#register-modified-date').val('<? echo $ar[0][0]['Modified_Date']; ?>');

  
    $('#register-HDate').val('<? echo $ar[1][0]['Record_Date']; ?>');
    $('#register-Height').val('<? echo $ar[1][0]['Height']; ?>');
    $('#register-Weight').val('<? echo $ar[1][0]['Weight']; ?>');
    $('#register-Waist').val('<? echo $ar[1][0]['Waist']; ?>');
    $('#register-Chest').val('<? echo $ar[1][0]['Chest']; ?>');
    $('#register-SugarLevel').val('<? echo $ar[1][0]['Sugar_Levels']; ?>');
    $('#register-BloodPressure').val('<? echo $ar[1][0]['Blood_Pressure']; ?>');
    $('#register-LipidProfile').val('<? echo $ar[1][0]['Lipid_Profile']; ?>');
    $('#register-Tyroid').val('<? echo $ar[1][0]['Thyroid']; ?>');
    $('#register-taken-by').val('<? echo $ar[1][0]['Taken_by']; ?>');
    $('#register-Hcreated-by').val('<? echo $ar[1][0]['Created_By']; ?>');
    $('#register-Hcreated-date').val('<? echo $ar[1][0]['Created_Date']; ?>');
    $('#register-Hmodified-by').val('<? echo $ar[1][0]['Modified_by']; ?>');
    $('#register-Hmodified-date').val('<? echo $ar[1][0]['Modified_date']; ?>');
*/

</script>



<?
$_SESSION['memupflag']=0;

}


}
else
   echo "<script>window.location.href='login.html' </script>";


?>