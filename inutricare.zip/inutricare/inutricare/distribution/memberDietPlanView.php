<?
  session_start();
  
      if(!isset($_SESSION['userid']))
         echo "<script>window.location.href='index.html'</script>";

    
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";
   
     $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
    }

    $sql="SELECT `Mb_ID` FROM `hMember_Demo` WHERE `memuserid`='".$_SESSION['userid']."'";
    $rs=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($rs);
    
?>


 <!-- The Modal -->
  <div class="modal fade" id="RecipeView">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Add Meal</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
        



<div class="project"   style=" transition: all 0.3s cubic-bezier(.25,.8,.25,1);">
                <div class="row bg-white has-shadow">
                  <div class="left-col col-lg-6 d-flex align-items-center justify-content-between">
                    <div class="project-title d-flex align-items-center">
                      <div class="image has-shadow"><img onclick="event.stopPropagation(); openOverlay(this)" id='recimg'  alt="..." class="img-fluid"></div>
                      <div class="text">
                        <h3 class="h4" id='recname'></h3><small><span id="recen"></span> Kcal</small>
                      </div>
                    </div>
                  
                  </div>
                  <div class="right-col col-lg-6 d-flex align-items-center">
                    <div class="time"><i class="fas fa-balance-scale"></i> </div>
                    <div class="comments"><i class="far fa-comments"></i>20</div>
                    <div class="project-progress" style="width:130px;">
                      <div class="progress">
                         <div role="progressbar" style="width: 45%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" class="progress-bar bg-red"></div>
                      </div>
                    </div>
                   
                    <div >  
                    </div>
                  </div>
                 
                   <div style="width:100%; ">
             <!--       <div class="line"></div>
                  <div class="row">
                    <div class=" col-lg-4 col-sm-6 d-flex align-items-center " style="justify-content:center;">

                      <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" ><strong id="recfat"></strong><br><small class="prop">Fat</small></div>

                      </div>
                      
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                        <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" style="padding-top: 10px;"><strong id="recene"></strong><br><small class="prop">Energy</small></div>

                      </div>
                  

                    
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                          <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text" ><strong id="reccarb"></strong><br><small class="prop">Carbohydrate</small></div>

                      </div>
                   
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center " style="justify-content:center;">

                        <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong id="recpro"></strong><br><small class="prop">Protein</small></div>

                      </div>
                  

                   
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                          <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong id="recfib"></strong><br><small class="prop">Fibre</small></div>

                      </div>
                      <div class=" col-lg-4 col-sm-6 d-flex align-items-center" style="justify-content:center;">

                        <div class="icon bg-green"><i class="fa fa-tasks"></i></div>
                    <div class="text"><strong id="recwat"></strong><br><small class="prop">Water</small></div>

                      </div>
                   </div>
     <div class="line"></div>
       
                            <h3 class="h4" style="text-align:center; font-size:25px; ">Properties</h3>
                          <div class="row" style="justify-content: space-evenly;" id="recprop">
                          <?php /*
                           $arrchk=  json_decode($RtempProp); 
                           $sql3="select * from hRecipe_Property";
  $result3=mysqli_query($conn,$sql3);
  $chkcnt=0;
        while($row = mysqli_fetch_assoc($result3))
        {
        if($arrchk[$chkcnt]=='true')
        echo "<div class='i-checks' style='padding: 0 10px;'>
                              <input id='checkboxCustom' type='checkbox' value='' disabled='' checked='' class='checkbox-template'>
                              <label for='checkboxCustom'>".$row['PropName']."</label>
                            </div>";
        $chkcnt++;
        }
                       */   ?>
                          </div>    
                     -->
              
                 <div class="line"></div>  
                            <h3 class="h4" style="text-align:center; font-size:25px; ">Steps of preparation</h3>
                <div class="row" style=" padding-left:10%;   align-items: center;">
                            <ol class="list-group vertical-steps" id="stepscontainer">
                         

 
   
</ol>

        </div>            
          </div>
              </div>
   </div>



        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="addRecipe()">Ok</button>
        </div>
        
      </div>
    </div>
  </div>

</div>
</div>
<div class="row" style="width: 100%;height: 100vh;">


 <div id="refresh"  style="width: 100%;">

  <!-- <button class="btn btn-primary" id="bmat" ><i class="fas fa-plus"></i></button>-->
<div  style=" background-color:white; box-shadow:2px 2px 2px lightgray; padding: 10px;" >
<div id="plans" class="text-center">

</div>



</div>




</div>

<script>
$( document ).ready(function(){
    showDietPlan();
});
 var cardCount=0;


var DietCount=1;
function showDietPlan(){

   var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {

   if (this.readyState == 4 && this.status == 200) {
          var ar=JSON.parse(this.responseText);
      var htm=$('#plans').html();
     var rcv=ar[0];
        $('#plans').html(htm+rcv);
        cardCount=ar[1];
        DietCount=ar[2];
        DietCount++;

fillname();
 $('.card21').remove();
    $('.addrecipe').remove();
  }
};


xmlhttp.open('POST','response.php?flag=memdietPlanView&mid='+<?php echo $row['Mb_ID'];?>,true);
 xmlhttp.send();
}

function  fillname(){
$('.card-title').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Meal Name'); 
});


$('.card-body small').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Meal Time'); 
});

$('.DietName').each(function(i, obj) {
    if(($(this).html()).trim()=="")
        $(this).html('Plan Name'); 
});

}

var ownerId=" <? echo $_SESSION['userid']; ?> ";

$(document).on("click",".recadded", function (event) {
 event.stopPropagation();
   var i=$(this).attr('data-recid');
    
    var x=new XMLHttpRequest();
    x.onreadystatechange=function(){
    
    if(this.readyState==4&&this.status==200){
    var j=JSON.parse(this.responseText);
    $('#recimg').attr('src',j[1]);
   /* $('#recen').html(j[4]);
    $('#recene').html(j[4]);
    $('#recwat').html(j[9]);
    $('#recfib').html(j[8]);
    $('#reccarb').html(j[6]);
    $('#recpro').html(j[7]);*/
    $('#recname').html(j[0]);
   var parr=JSON.parse(j[12]);
   var str="";
for (var i = 0; i <j[14].length; i++) {
  if(parr[i]==true)
    {
      str=str+"<div class='i-checks' style='padding: 0 10px;'><input id='checkboxCustom' type='checkbox' value='' disabled='' checked='' class='checkbox-template'><label for='checkboxCustom'>"+j[14][i]+"</label></div>";
    }
}
var str1="";
for (var i = 0; i <j[13].length; i++) {
str1+="  <li class='list-group-item active'><span> "+j[13][i]+" </span></li>"
}
$('#stepscontainer').html(str1);
    $('#recprop').html(str);
    
    $('#RecipeView').modal();

    }
   
    };
    x.open('POST','response.php?flag=memrecview&rid='+i,true);
    x.send();
   
});


function toggle(id){
whichPlanOpenId=id;
$('.accord').each(function(i,o){
  $(o).slideUp();
});

if($('#'+id).css("display")!='block') 
$('#'+id).slideToggle();
}



</script>

<style>
.tab{
 background:#eef5f9;
}

#bmat{
border-radius:50%;
}
.showit{
display:block;
}
.hideit{

display:none;
}
.project:hover{

cursor:pointer;

}

.card-body{
background-color:#796aee17;
    padding-bottom: 0.5rem;
}
  .card2{
   font-size:18px;
  font-weight:400;
    border-radius: 5px 5px 5px 5px;
    display: inline-block;
    background-color: #f7f7f7;
    width: 300px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    margin-top: 10px;
    margin-left: 10px;
    margin-right:10px;
    margin-bottom: 10px;
    transition: all 0.3s cubic-bezier(.25,.8,.25,1);

  }
  .card2:hover{
    cursor: pointer;
  }
.card2:hover {
    box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}
 .card2 > .card-img-bottom{
    width: 300px;
    height: 300px;
    border-radius: 5px 5px 0px 0px;
   // background-color: #dc6b3f;
    text-align: left;
    color: #fff;
    padding: 5% 5% 7% 8%;
    min-height: 75px;
overflow:auto;
  }
.card2:hover .card-img-bottom{
color:gray !important;
border-color:gray !important;
}

 .card2 > .card-img-top{
    width: 300px;
    height: 300px;
    border-radius: 5px 5px 0px 0px;
   // background-color: #dc6b3f;
    text-align: left;
    color: #fff;
    padding: 8% 5% 7% 8%;
    min-height: 75px;
overflow:auto;
  }
.card2:hover .card-img-top{
color:gray !important;
border-color:gray !important;
}
.card2:hover #onei{

color:gray!important;
}

.addrecipe:hover{
border-color:gray !important;
color:gray!important;
}
.addrecipe:hover i{
color :gray !important;
}
#plusAddPlanBtn{
transition: all 0.3s;
width:50px;
height: 50px;
}
#plusAddPlanBtn:hover{
transform: rotate(180deg);
}
/*
#plusAddPlanBtn:hover + #showPlanMsg{
opacity: 1;
padding-left: 10px;
}*/

#showPlanMsg{
      width: max-content;
    display: flex;
    align-items: center;
   transition: all 0.3s;
padding-left: 10px;
    font-size: 18px;
    font-weight: 600;
  '  opacity:0;
}
.recadded:hover{
//box-shadow:-56px 0px 49px #00000024 inset;
}
.recadded:hover .close{
visibility: unset ;
 
}
.recadded .close{
visibility: hidden;

}
/*
.recadded {
transition:none;
background-color:white; color:black!important;width=100%; padding: 5px;     display: flex;justify-content: space-between; align-items:center;

}
*/
.nav-tabs:hover{
cursor:pointer;
}
.fil:hover{
cursor:pointer;

}



</style>
