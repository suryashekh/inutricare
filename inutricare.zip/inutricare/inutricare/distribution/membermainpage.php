<?php
session_start();
  if(isset($_SESSION['userid'])){
  
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";
 
 $conn = mysqli_connect($servername, $username, $password, $dbname);
  if (!$conn) {
      die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
  }
  
  
  $sql="select * from hAuthentication where Auth_UserID='".$_SESSION['userid']."'";
  $result=mysqli_query($conn,$sql);
  
     
    
    
 


?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bootstrap Material Admin by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
  
  
  <?php
   echo "<script>
     var usrflag;
        </script>";
    if(mysqli_num_rows($result)>0){
    $row = mysqli_fetch_assoc($result);
      if($row['Auth_Roleid']=='D'){
        $_SESSION['role']="D";
        $sql1="Select * from hDietician_Enrollment where Dt_Userid='".$_SESSION['userid']."'";
        $result1=mysqli_query($conn,$sql1);
            if(mysqli_num_rows($result1)>0){
              $row1 = mysqli_fetch_assoc($result1);
              $_SESSION['userimage']=$row1['Dt_Photo'];
              $_SESSION['username']=$row1['Dt_Name'];
        }
      }
   else if($row['Auth_Roleid']=='M'){
        $_SESSION['role']="M";
        echo "<script>
     usrflag='m';
        </script>";
      }
  }
    
}
else{
  echo "<script>window.location.href='index.html' </script>";
  
}
  ?>
  <style>
  #myImg {
    border-radius: 5px;
    cursor: pointer;
    transition: 0.3s;
}

#myImg:hover {opacity: 0.7;}

/* The Modal (background) */
.md1{
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 40; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.9); /* Black w/ opacity */
}

/* Modal Content (image) */
.mdc {
    margin: auto;
    display: block;
    width: 30%;
    max-width: 700px;
}

/* Caption of Modal Image */
#caption {
    margin: auto;
    display: block;
    width: 50%;
    max-width: 700px;
    text-align: center;
    color: #ccc;
    padding: 10px 0;
    height: 150px;
}

/* Add Animation */
.mdc, #caption {    
    -webkit-animation-name: zoom;
    -webkit-animation-duration: 0.6s;
    animation-name: zoom;
    animation-duration: 0.6s;
}

@-webkit-keyframes zoom {
    from {-webkit-transform:scale(0)} 
    to {-webkit-transform:scale(1)}
}

@keyframes zoom {
    from {transform:scale(0)} 
    to {transform:scale(1)}
}

/* The Close Button */
.cl{
    position: absolute;
    top: 15px;
    right: 35px;
    color: #f1f1f1;
    font-size: 40px;
    font-weight: bold;
    transition: 0.3s;
}

.cl:hover,
.cl:focus {
    color: #bbb;
    text-decoration: none;
    cursor: pointer;
}

/* 100% Image Width on Smaller Screens */
@media only screen and (max-width: 700px){
    .mdc {
        width: 50%;
    }
}
</style>

  <div id="myModal" class="modal md1" onclick="event.stopPropagation(); this.style.display='none';">
  <span class="close cl">&times;</span>
  <img class="modal-content mdc" id="img01">
  <div id="caption"></div>
</div>

  
  <script>

function openOverlay(ele){
var modal = document.getElementById('myModal');
var modalImg = document.getElementById("img01");
    modal.style.display = "block";
    modalImg.src = ele.src;
 //   captionText.innerHTML = ele.alt;

}



// Get the <span> element that closes the modal
var span = document.getElementsByClassName("cl")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() { 
    document.getElementById('myModal').style.display = "none";
}

</script>




    <div class="page">
      <!-- Main Navbar-->
      <header class="header">
        <nav class="navbar">
          <!-- Search Box-->
          <div class="search-box">
            <button class="dismiss"><i class="icon-close"></i></button>
            <form id="searchForm" action="#" role="search">
              <input type="search" placeholder="What are you looking for..." class="form-control">
            </form>
          </div>
          <div class="container-fluid">
            <div class="navbar-holder d-flex align-items-center justify-content-between">
              <!-- Navbar Header-->
              <div class="navbar-header">
                <!-- Navbar Brand --><a href="index.html" class="navbar-brand d-none d-sm-inline-block">
                  <div class="brand-text d-none d-lg-inline-block"><span>Bootstrap </span><strong>Dashboard</strong></div>
                  <div class="brand-text d-none d-sm-inline-block d-lg-none"><strong>BD</strong></div></a>
                <!-- Toggle Button--><a id="toggle-btn" href="#" class="menu-btn active"><span></span><span></span><span></span></a>
              </div>
              <!-- Navbar Menu -->
              <ul class="nav-menu list-unstyled d-flex flex-md-row align-items-md-center">
                <!-- Search-->
                <li class="nav-item d-flex align-items-center"><a id="search" href="#"><i class="icon-search"></i></a></li>
                <!-- Notifications-->
                <li class="nav-item dropdown"> <a id="notifications" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link"><i class="fa fa-bell-o"></i><span class="badge bg-red badge-corner">12</span></a>
                  <ul aria-labelledby="notifications" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-envelope bg-green"></i>You have 6 new messages </div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-twitter bg-blue"></i>You have 2 followers</div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-upload bg-orange"></i>Server Rebooted</div>
                          <div class="notification-time"><small>4 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> 
                        <div class="notification">
                          <div class="notification-content"><i class="fa fa-twitter bg-blue"></i>You have 2 followers</div>
                          <div class="notification-time"><small>10 minutes ago</small></div>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item all-notifications text-center"> <strong>view all notifications                                            </strong></a></li>
                  </ul>
                </li>
                <!-- Messages                        -->
                <li class="nav-item dropdown"> <a id="messages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link"><i class="fa fa-envelope-o"></i><span class="badge bg-orange badge-corner">10</span></a>
                  <ul aria-labelledby="notifications" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-1.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Jason Doe</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-2.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Frank Williams</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item d-flex"> 
                        <div class="msg-profile"> <img src="img/avatar-3.jpg" alt="..." class="img-fluid rounded-circle"></div>
                        <div class="msg-body">
                          <h3 class="h5">Ashley Wood</h3><span>Sent You Message</span>
                        </div></a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item all-notifications text-center"> <strong>Read all messages   </strong></a></li>
                  </ul>
                </li>
                <!-- Languages dropdown    -->
                <li class="nav-item dropdown"><a id="languages" rel="nofollow" data-target="#" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link language dropdown-toggle"><img src="img/flags/16/GB.png" alt="English"><span class="d-none d-sm-inline-block">English</span></a>
                  <ul aria-labelledby="languages" class="dropdown-menu">
                    <li><a rel="nofollow" href="#" class="dropdown-item"> <img src="img/flags/16/DE.png" alt="English" class="mr-2">German</a></li>
                    <li><a rel="nofollow" href="#" class="dropdown-item"> <img src="img/flags/16/FR.png" alt="English" class="mr-2">French                                         </a></li>
                  </ul>
                </li>
                <!-- Logout    -->
                <li class="nav-item"><a href="login.html" class="nav-link logout"> <span class="d-none d-sm-inline">Logout</span><i class="fa fa-sign-out"></i></a></li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
      <div class="page-content d-flex align-items-stretch" id="whole-content"> 
        <!-- Side Navbar -->
        <nav class="side-navbar">
          <!-- Sidebar Header-->
          <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img onclick="changeToUpdateDietician()" id="dieticianImg" src="https://upload.wikimedia.org/wikipedia/commons/7/7e/Circle-icons-profile.svg" alt="..." class="img-fluid rounded-circle"></div>
            <div class="title">
              <h1 class="h4"><?php echo $_SESSION['username']; ?></h1>
              <p><?php if($_SESSION['role']=="D") echo 'Dietician'; else if($_SESSION['role']=="M") echo 'Member'; ?></p>
            </div>
          </div>
          <!-- Sidebar Navidation Menus--><span class="heading">Main</span>
          <ul class="list-unstyled">
                    <li class="active"><a onclick="changeToMemDietPlan()"> <i class="icon-home"></i>My Diet Plans</a></li>
                     <li><a onclick="changeToMember()" > <i class="icon-interface-windows"></i>Members</a>
                    
                    </li>
                       <li><a href="#exampledropdownDropdown1" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Recipe</a>
                      <ul id="exampledropdownDropdown1" class="collapse list-unstyled ">
                        <li><a onclick="changeToRecipeView()">View</a></li>
                        <li><a onclick="changeToRecipeAdd()">Add</a></li>
                      </ul>
                    </li>
 <li><a onclick="changeToDietPlan()" > <i class="icon-grid"></i>Diet Plans</a></li>
                    <li><a onclick="changeToPendingApproval()" > <i class="icon-grid"></i>Pending Approval </a></li>
                    <li><a href="charts.html"> <i class="fa fa-bar-chart"></i>Charts </a></li>
                    <li><a href="forms.html"> <i class="icon-padnote"></i>Forms </a></li>
                    <li><a href="login.html"> <i class="icon-interface-windows"></i>Login page </a></li>
          </ul><span class="heading">Extras</span>
          <ul class="list-unstyled">
            <li> <a href="#"> <i class="icon-flask"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-screen"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-mail"></i>Demo </a></li>
            <li> <a href="#"> <i class="icon-picture"></i>Demo </a></li>
          </ul>
        </nav>
        <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom" id="head-label">Dashboard</h2>
            </div>
          </header>



          <div id="sec-to-show" style="padding:50px;">
          <!--  Section-->
        
          </div>
   


          <!-- Page Footer-->
          <footer class="main-footer">
            <div class="container-fluid">
              <div class="row">
                <div class="col-sm-6">
                  <p>Your company &copy; 2017-2019</p>
                </div>
                <div class="col-sm-6 text-right">
                  <p>Design by <a href="https://bootstrapious.com/admin-templates" class="external">Bootstrapious</a></p>
                  <!-- Please do not remove the backlink to us unless you support further development at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
    </div>
    <style type="text/css">
    
    #dieticianImg:hover{
    cursor:pointer;
    }
    
    
      .line{
            width: 100%;
    height: 1px;
    border-bottom: 1px dashed #eee;
    margin: 30px 0;
      }
/*Vertical Steps*/
.list-group.vertical-steps{
  padding-left:10px;
}
.list-group.vertical-steps .list-group-item{
  border:none;
  border-left:3px solid #ece5dd;
  box-sizing:border-box;
  border-radius:0;
  counter-increment: step-counter;
  padding-left:20px;
  padding-right:0px;
  padding-bottom:20px;  
  padding-top:0px;
}
.list-group.vertical-steps .list-group-item.active{
  background-color:transparent;
  color:inherit;
}
.list-group.vertical-steps .list-group-item:last-child{
  border-left:3px solid transparent;
  padding-bottom:0;
}
.list-group.vertical-steps .list-group-item::before {
  border-radius: 50%;
  background-color:#ece5dd;
  color:#555;
  content: counter(step-counter);
  display:inline-block;
  float:left;
  height:25px;
  line-height:25px;
  margin-left:-35px;
  text-align:center;  
  width:25px;  
}
.list-group.vertical-steps .list-group-item span,
.list-group.vertical-steps .list-group-item a{
  display:block;
  overflow:hidden;
  padding-top:2px;
}
/*Active/ Completed States*/
.list-group.vertical-steps .list-group-item.active::before{
  background-color:#0052c2;
  color:#fff;
}
.list-group.vertical-steps .list-group-item.completed{
  border-left:3px solid #0052c2;
}
.list-group.vertical-steps .list-group-item.completed::before{
  background-color:#0052c2;
  color:#fff;
}
.list-group.vertical-steps .list-group-item.completed:last-child{
  border-left:3px solid transparent;
}
*{
transition : all 0.3s;
}

    </style>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
    <script type="text/javascript">

    $("input[type='date' i]").on("change", function() {
    $(this).css('color','black');
   
});


   $(function(){
  changeToMemDietPlan();
   });
      var stepsCount=1;
    
      var RecipeAdd=0;
      var RecipeAddStr="";
      function changeToRecipeAdd()
       {
         /* 
           if (RecipeAdd==0) 
           {
           
                $.get("RecipeAdd.php", function(response) {
              RecipeAddStr = response;
             $('#sec-to-show').html(RecipeAddStr);
                });
                RecipeAdd++;
            }
        else{
        
               $('#sec-to-show').html(RecipeAddStr);
            }
     $('#RecipeReviewer').html(Rselect);
    
     */
     $('#sec-to-show').load('RecipeAdd.php');
        
      }
      
       var RecipeView=0;
      var RecipeViewStr="";
      function changeToMemDietPlan()
       {
        // $('#sec-to-show').html("<img src='https://i.giphy.com/media/jAYUbVXgESSti/giphy.webp' />");   
          $('#sec-to-show').load('memberDietPlanView.php');
    
        
      } 
      
         function changeToPendingApproval()
       {
           
          $('#sec-to-show').load('PendingApproval.php');
    
        
      }
         function changeToUpdateDietician()
       {
           
          $('#sec-to-show').load('UpdateDietician.php');
    
        
      }
      
      function changeToMember(){
      
      $('#sec-to-show').load('membersView.php');
      
      }
       function changeToDietPlan(){
      
      $('#sec-to-show').load('DietPlan.php');
      
      }

       var Profile=0;
      var ProfileStr="";
      function changeToProfile(){
        if (Profile==0) 
           {
                $.get("Dashboard.txt", function(response) {
              ProfileStr = response;
             $('#sec-to-show').html(ProfileStr);
                });
                Profile++;
            }
        else{
        
               $('#sec-to-show').html(ProfileStr);
            }
      }
 

    </script>
  </body>
</html>