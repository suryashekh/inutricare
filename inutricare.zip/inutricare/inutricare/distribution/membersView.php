<?
session_start();
if(isset($_SESSION['userid'])){

$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";



    $conn = mysqli_connect($servername, $username, $password, $dbname);
    if (!$conn) {
        die("<br><br><script> alert('connnection failed " . mysqli_connect_error()."');</script>");
    }
   $sql="select * from hDietician_Enrollment where Dt_Userid='".$_SESSION['userid']."'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);


    $sql= "SELECT Mb_ID, Mb_Name, Mb_Age, Mb_Gen FROM hMember_Demo where Dt_AuthID='".$row['Dt_AuthID']."'";
    $result=mysqli_query($conn,$sql);
   $cnt=0;
    
       
  
?>

<style type="text/css">
  .mg-top-btm{
    margin:5px 2px;
  }
  .just{
    justify-content: space-evenly;
  }
  .alignCenter{
    align-items: center;
  }
  .flx{
    display: flex;
  }

  


</style>
<div class="col-lg-12">
    <div class="card">
        <div class="card-close">
            <div class="dropdown" >
                <button type="button" id="closeCard5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle"><i class="fa fa-ellipsis-v"></i></button>
                <div aria-labelledby="closeCard5" class="dropdown-menu dropdown-menu-right has-shadow"><a href="#" onclick="activeMem()" class="dropdown-item remove"> <i class="fa fa-gear"></i>Active Members</a><a href="#" onclick="allMem()" class="dropdown-item edit"> <i class="fa fa-gear"></i>All Members</a></div>
            </div>
        </div>
        <div class="card-header d-flex align-items-center">
            <h3 class="h4">Member View</h3>


        </div>

        <div class="card-body">
          <div class="row">
             
             <div class="col-sm-8 col-xs-12 flx " style="justify-content: flex-end;" > <input id="srcstr" type="text" class="form-control"/> <button id="srchme" class="btn btn-primary">Search</button></div>
             <!-- <form class="search-container" >
  <input id="search-box" type="text" class="search-box" name="q" />
  <label for="search-box"><span class="glyphicon glyphicon-search search-icon"></span></label>
  <input type="submit" id="search-submit" />
</form>-->
              <div class="col-sm-4 col-xs-12 flx just "><button type="button" onclick="assignTo()" class="btn btn-primary" data-toggle="modal" data-target="#myModal1">
  Assign to
</button>

<!-- The Modal -->
<div class="modal" id="myModal1">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Assign Dietician</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body" style="max-height:60vh; overflow-y:scroll;">
                              <table class="table table-hover" style="text-align:center;">
                                <thead>
                <th>ID </th>
                <th>Name</th>
                <th></th>
            
              </thead>
              <tbody>
                                 <?php
  
                                       $sql = "SELECT * FROM `hDietician_Enrollment`";
      $rs= mysqli_query($conn,$sql);
                              while($row=mysqli_fetch_assoc($rs)){
                                              echo "<tr> <td>".$row['Dt_AuthID']."</td>
                                                    <td>".$row['Dt_Name']."</td>
                                                      <td><button id='".$row['Dt_AuthID']."' onclick='assignMember(".$row['Dt_AuthID'].")' class='btn btn-primary'>Assign</button> </td></tr>";
                                       }
                                 ?>
                </tbody>
                               </table>
                            </div>
                            <div class="modal-footer">
                              <button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
                            
                            </div>
                          </div>
                        </div>
                      </div>






               <button class="btn btn-primary " onclick="addmember()">Add Member</button></div>
          </div>

          <div class="row">
            <div class="table-responsive-sm" style="width: 100%; margin: 30px 0px;">
            <table class="table table-hover " style="text-align:center;">
              <thead>
                <th> </th>
                <th>Name</th>
                <th>Age</th>
                <th>Gender</th>
               
                <th></th>

              </thead>
              <tbody id='tbod'>
             
                
                <?php
              
                 while( $row = mysqli_fetch_assoc($result))                
{
                $cnt++;
                ?>
                 <tr onclick="$('#check<? echo $cnt; ?>').click();" >
                  <td> <input type="checkbox" id='check<? echo $cnt; ?>' value="<? echo $row['Mb_ID']; ?>" class="checkbox-template" name=""></td>
                <td><? echo $row['Mb_Name']; ?></td>
                <td><? echo $row['Mb_Age']; ?></td>
    <td><? echo $row['Mb_Gen']; ?></td>
    
               
            
        
                                <td><button class="btn btn-light" onclick="event.stopPropagation(); Upmem(<? echo $row['Mb_ID']; ?>) " >Update</button></td>
        </tr>
      <?php
      
      
     }
              

               echo "<script>var cnt=".$cnt.";</script>";
  
    ?>
                
              </tbody>
            </table>
          
          </div>

          </div>
           
            </div>
        </div>
    </div>

    <script>



        var materialInputs = $('input.input-material');

        // activate labels for prefilled values
        materialInputs.filter(function() { return $(this).val() !== ""; }).siblings('.label-material').addClass('active');

        // move label on focus
        materialInputs.on('focus', function () {
            $(this).siblings('.label-material').addClass('active');
        });

        // remove/keep label on blur
        materialInputs.on('blur', function () {
            $(this).siblings('.label-material').removeClass('active');

            if ($(this).val() !== '') {
                $(this).siblings('.label-material').addClass('active');
            } else {
                $(this).siblings('.label-material').removeClass('active');
            }
        });


function activeMem(){
 
       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
                if(this.status==200 && this.readyState==4)
                     {
                        $('#tbod').html(this.responseText);
                    }

                  }
    x.open('POST','response.php?flag=activemem');
    x.send();
}
function allMem(){
	
       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
                if(this.status==200 && this.readyState==4)
                     {
                        $('#tbod').html(this.responseText);
                    }

                  }
    x.open('POST','response.php?flag=allmem');
    x.send();
}
      

        function addmember(){
          $('#sec-to-show').load('memberAdd.php');
        }

      $('#srchme').click(function(){
      srchmem();
});

$('#srcstr').keyup(function(){
 srchmem();
});

      function srchmem(){

       var x=new XMLHttpRequest();
       x.onreadystatechange=function(){
                if(this.status==200 && this.readyState==4)
                     {
                        $('#tbod').html(this.responseText);
                    }

                  }
    x.open('POST','response.php?memsrc='+$('#srcstr').val()+'&flag=memsrc');
    x.send();
}

function Upmem(id){
var x=new XMLHttpRequest();
x.onreadystatechange=function(){
if(this.status==200&&this.readyState==4)
{
  if(JSON.parse(this.responseText)[2]=="true")
   {
     $('#sec-to-show').load('memberAdd.php');
   }
  else
  {
   alert('Updation failed');
  }
}

}
x.open('POST','response.php?flag=upmem&id='+id,true);
x.send();
}


var car;
       var tmp=0;
var chkarr;
function assignTo(){

        chkarr=new Array();
 tmp=0;
       for (var i=0;i<cnt;i++){
        if(($('#check'+(i+1)).is(":checked"))==true)
          {     
                chkarr[tmp++]=$('#check'+(i+1)).val();
          }
        }
        car=JSON.stringify(chkarr);
       
}

function assignMember(id){

  var x=new XMLHttpRequest();
x.onreadystatechange=function(){
if(this.status==200&&this.readyState==4)
{
  alert(chkarr.length+' Members assigned');

}

}


x.open('POST','response.php?flag=assignmem&car='+car+'&Did='+id,true);
x.send();

}

$('#myModal1').on('hidden.bs.modal', function (e) {
   $('#sec-to-show').load('membersView.php');
});

    </script>


<?php
}
?>

