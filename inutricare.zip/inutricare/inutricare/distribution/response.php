<?php

session_start();
$servername = "localhost";
$username = "root";
$password = "Helloworld@123";
$dbname = "mmepapp";
 
 
$conn = mysqli_connect($servername, $username, $password, $dbname);
  if (!$conn) {
      die("<br><br><script> alert('connnection failed')" . mysqli_connect_error()."</script>");
  }
  
$flag=$_REQUEST['flag'];
if($flag=='1'){
$nm=$_REQUEST['name'];
$ad=$_REQUEST['addr'];
$st=$_REQUEST['state'];
$ct=$_REQUEST['city'];
$ph=$_REQUEST['phno'];
$ap=$_REQUEST['altphno'];
$em=$_REQUEST['email'];
$fd=$_REQUEST['fdate'];
$td=$_REQUEST['tdate'];
$ty=$_REQUEST['type'];
$ye=$_REQUEST['yexp'];
$sa=$_REQUEST['salary'];
$de=$_REQUEST['design'];
$su=$_REQUEST['status'];
$cb=$_REQUEST['createdby'];
$cd=$_REQUEST['createddt'];
$mb=$_REQUEST['modifiedby'];
$md=$_REQUEST['modifieddt'];



 if(isset($_FILES['photo'])){
 $dir="ImageFiles";
      $errors= array();
      $file_name = rand().$_FILES['photo']['name'];
      $file_size =$_FILES['photo']['size'];
      $file_tmp =$_FILES['photo']['tmp_name'];
      $file_type=$_FILES['photo']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['photo']['name'])));
      
   //   $expensions= array("jpeg","jpg","png");
      
  /*    if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
  */
  
  
  
  
  
  
  if (!file_exists($dir)) {
      mkdir($dir, 0777, true);
  }
  
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,$dir."/".$file_name);
         
      }
   }
   
   $photoDest=$dir."/".$file_name;
   
   $usr=rand();
    $pwd= rand();
   
   $sql ="INSERT INTO hDietician_Enrollment (Dt_Name, Dt_Address,Dt_City, Dt_State, Dt_Phone, Dt_AltContact, Dt_Email, Dt_Effdate, Dt_Termdt, Dt_Type, Dt_Yrs, Dt_Salary, Dt_Designation, Dt_Photo, Dt_Access, Created_By, Created_Date, Modified_By, Modified_Date,Dt_Userid) VALUES ('".$nm."','".$ad."','".$ct."','".$st."','".$ph."','".$ap."','".$em."','".$fd."','".$td."','".$ty."','".$ye."','".$sa."','".$de."','".$photoDest."','".$su."','".$cb."','".$cd."','".$mb."','".$md."','".$usr."')";
   

  $result = mysqli_query($conn, $sql);
  
  
  
  
    
    
    $sql1="INSERT INTO `hAuthentication` (`Auth_UserID`, `Auth_Password`, `Auth_Roleid`, `Auth_Denyaccess`) VALUES ('".$usr."','".encryptIt($pwd)."','D','1')";
    $result1 = mysqli_query($conn, $sql1);
    
    
    $msg = "<html><body><center><h1>Your UserName and Password are here..</h1></center><br><br><br><center> <b>Username: <u>".$usr."</u><br><br>Password: <u>".$pwd."</u></b></center></body></html>";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  mail($em,"Welcome, Yours Credentials are here",$msg,$headers);

if ($result)
{
echo "Credentials have been sent. Check email.";
}
 else
 echo mysqli_error($conn);
 
 if (!$result)
 echo mysqli_error($conn);
}

else if($flag=="2"){

$u=$_REQUEST['u'];
$p=$_REQUEST['p'];

$sql = "select * from hAuthentication where Auth_UserID='".$u."' and Auth_Password='".encryptIt($p)."'";

$result = mysqli_query($conn, $sql);
  if (mysqli_num_rows($result) > 0){ 
  $_SESSION['userid']=$u;
  echo "true";
  }
  else
  echo "false";

}
else if($flag==3){

        $nm=$_REQUEST['nm'];
        $wt=$_REQUEST['wt'];
        $unt=$_REQUEST['unt'];
        $ft=$_REQUEST['ft'];
        $en=$_REQUEST['en'];
        $ca=$_REQUEST['ca'];
        $pr=$_REQUEST['pr'];
        $fb=$_REQUEST['fb'];
        $wa=$_REQUEST['wa'];
      //  $rp=$_REQUEST['rp'];
        $rd=$_REQUEST['rd'];
        $chk=$_REQUEST['chk'];
        $stp=$_REQUEST['step'];
        $ta=$_REQUEST['ta'];
      
         if(isset($_FILES['rp'])){
        
 $dir="RecipeImageFiles";
      $errors= array();
      $file_name = rand().$_FILES['rp']['name'];
      $file_size =$_FILES['rp']['size'];
      $file_tmp =$_FILES['rp']['tmp_name'];
      $file_type=$_FILES['rp']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['rp']['name'])));
      

   //   $expensions= array("jpeg","jpg","png");      
  /*    if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
  */
  
  
  
  
  
  
  if (!file_exists($dir)) {
      mkdir($dir, 0777, true);
  }
  
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,$dir."/".$file_name);
         
      }
      
      $photoDestR=$dir."/".$file_name;
   }
   else {
   $photoDestR=$_REQUEST['rp'];
  
   }
   

   
        
        $sql="INSERT INTO `hRecipes`( `Recipe_Name`, `Unit_Of_Measure`, `Quantity`, `Recipe_Pic`, `Energy_Kcal`, `Fats`, `Carbohydrate`, `Protein`, `Fibre`, `Water`, `Recipe_Link`, `Reviewer_Dt_Id`, `Approved`, `Userid`, `Properties`) VALUES ('".$nm."' ,'".$unt."' ,'".$wt."' , '". $photoDestR."','".$en."' ,'".$ft ."' ,'".$ca ."' ,'".$pr ."' , '".$fb."', '".$wa."','','".$rd."' ,'false' ,'".$_SESSION['userid']."','".$chk."' )";
       
       
       
         $result2 = mysqli_query($conn, $sql);
          $R_id = mysqli_insert_id($conn);
          
            $steps_arr=json_decode($ta);
  $steps_temp="INSERT INTO `hRecipe_Steps`( `Rid`, `steps`) VALUES ";
  foreach($steps_arr as $st){
  $steps_temp.="('".$R_id."','".$st."'),";
  
  }
  
  $steps_temp=substr($steps_temp, 0, -1);
   $result5 = mysqli_query($conn, $steps_temp);
          
          $sql="Select Dt_PendingApproval from `hDietician_Enrollment` WHERE Dt_Userid='".$rd."'";
       
         $result3 = mysqli_query($conn, $sql);
         $row=mysqli_fetch_assoc( $result3);
         if($row['Dt_PendingApproval']!='[]')
        $pen= json_decode($row['Dt_PendingApproval']);
        else 
        $pen = array();
        
        array_push($pen,$R_id);
         $pen=json_encode($pen);
            $sql="UPDATE `hDietician_Enrollment` SET `Dt_PendingApproval`='".$pen."' WHERE Dt_Userid='".$rd."'";
       
         $result4 = mysqli_query($conn, $sql);
         
         
         if(!$result2)
         {
           echo "error ".mysqli_error($conn);
         }   
         else  if(!$result3)
         {
           echo "error ".mysqli_error($conn);
         }
         else  if(!$result4)
         {
           echo "error ".mysqli_error($conn);
         }
           else  if(!$result5)
         {
           echo "error ".mysqli_error($conn);
         }
         else
          echo "Recipe submitted";
}
else if($flag==4)
{
$_SESSION['Rflag']=1;
$_SESSION['Rid']=$_REQUEST['id'];
$_SESSION['Rarr1']=$_REQUEST['Rarr'];

}
else if($flag==6)
{
$_SESSION['Rflag']=2;
$_SESSION['Rid']=$_REQUEST['id'];
$_SESSION['Rarr1']=$_REQUEST['Rarr'];

}
else if($flag==5)
{
    $nm=$_REQUEST['nm'];
        $wt=$_REQUEST['wt'];
          $unt=$_REQUEST['unt'];
        $ft=$_REQUEST['ft'];
        $en=$_REQUEST['en'];
        $ca=$_REQUEST['ca'];
        $pr=$_REQUEST['pr'];
        $fb=$_REQUEST['fb'];
        $wa=$_REQUEST['wa'];
      //  $rp=$_REQUEST['rp'];
        $rd=$_REQUEST['rd'];
        $chk=$_REQUEST['chk'];
        $stp=$_REQUEST['step'];
        $ta=$_REQUEST['ta'];
        $rid= $_REQUEST['Rid'];
      
         if(isset($_FILES['rp'])){
        
 $dir="RecipeImageFiles";
      $errors= array();
      $file_name = rand().$_FILES['rp']['name'];
      $file_size =$_FILES['rp']['size'];
      $file_tmp =$_FILES['rp']['tmp_name'];
      $file_type=$_FILES['rp']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['rp']['name'])));
      

   //   $expensions= array("jpeg","jpg","png");      
  /*    if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      
      if($file_size > 2097152){
         $errors[]='File size must be excately 2 MB';
      }
  */
  
  
  
  
  
  
  if (!file_exists($dir)) {
      mkdir($dir, 0777, true);
  }
  
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,$dir."/".$file_name);
         
      }
       $photoDestR=$dir."/".$file_name;
   }
   else {
    $photoDestR=$_REQUEST['rp'];
  
   }
   
   $sql="delete from hRecipe_Steps where Rid ='".$rid."'";
    $result3 = mysqli_query($conn, $sql);
    $steps_arr=json_decode($ta);
  $steps_temp="INSERT INTO `hRecipe_Steps`( `Rid`, `steps`) VALUES ";
  foreach($steps_arr as $st){
  $steps_temp.="('".$rid."','".$st."'),";
  }
  
   $steps_temp=substr($steps_temp, 0, -1);
   $result4 = mysqli_query($conn, $steps_temp);
   
  
        $sql="UPDATE `hRecipes` SET `Recipe_Name`='".$nm."' ,`Unit_Of_Measure`='".$unt."' ,`Quantity`='".$wt."',`Recipe_Pic`='". $photoDestR."',`Energy_Kcal`='".$en."',`Fats`='".$ft ."',`Carbohydrate`='".$ca ."',`Protein`='".$pr ."',`Fibre`='".$fb."',`Water`='".$wa."',`Recipe_Link`='',`Reviewer_Dt_Id`='".$rd
        ."',`Approved`='false',`Userid`='".$_SESSION['userid']."',`Properties`='".$chk."' where Recipe_ID=".$rid;
        
       
         
         $result2 = mysqli_query($conn, $sql);
         if(!$result2)
         {
           echo "error ".mysqli_error($conn);
         }
          else  if(!$result3)
         {
           echo "error ".mysqli_error($conn);
         }
          else  if(!$result4)
         {
           echo "error ".mysqli_error($conn);
         }   
         else
          echo "Recipe Updated";

}
else if($flag==7){
  ini_set("auto_detect_line_endings", true);
  $er=0;

  $pglobal=array();
  
 if(isset($_FILES["csv"])){
    
    $filename=$_FILES["csv"]["tmp_name"];   
    

     if($_FILES["csv"]["size"] > 0)
     {
        $file = fopen($filename, "r");
        $cnt=0;
        $pline=array();
        array_push($pline,'Recipe Id');
        array_push($pline,'Recipe Name');
        array_push($pline,'Steps');
        array_push($pglobal,$pline);
          while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
           { 
       $pline=array();
            $cnt++;
               if($cnt==1||$cnt==2)
           continue;
          
                     $sql="INSERT INTO `hRecipes`( `Recipe_Name`, `Unit_Of_Measure`, `Quantity`, `Recipe_Pic`, `Energy_Kcal`, `Fats`, `Carbohydrate`, `Protein`, `Fibre`, `Water`, `Recipe_Link`, `Reviewer_Dt_Id`, `Approved`, `Userid`, `Properties`) VALUES ('".$getData[0]."' ,'".$getData[1]."' ,'".$getData[2]."' , '".$getData[3]."','".$getData[4]."' ,'".$getData[5] ."' ,'".$getData[6] ."' ,'".$getData[7] ."' , '".$getData[8]."', '".$getData[9]."','','".$getData[11]."','".$getData[12]."','".$getData[13]."','".$getData[14]."' )";
                     $result = mysqli_query($conn, $sql);
                     $rid=mysqli_insert_id($conn);
        if(!$result)
        {
            $er=1;    
        }
        else
        {
          array_push($pline,  $rid);
          array_push($pline,  $getData[0]);
          array_push($pglobal,$pline);  
        }
        
           }
      
           fclose($file); 
     }
     else{
  
      echo "Error,file not uploaded"  ; 
      $er=1;
      }
      
      
      $R_id = mysqli_insert_id($conn);
  }
  else{
  
  $er=1;
  }
  if($er==1)
  {
   $datatosend=array(); 
   array_push($datatosend,"Error,file not uploaded. Check CSV");
   array_push($datatosend,"false");
   echo json_encode($datatosend);
  }
  else
  { $datatosend=array(); 
  array_push($datatosend,"Data Successfully Inserted, ".($cnt-1)." rows afffected");
  
  $fp = fopen('Upload Steps.csv', 'w');

  foreach ($pglobal as $fields) {
      fputcsv($fp, $fields);
  }
  
  array_push($datatosend,"true");
   echo json_encode($datatosend);
  }

 
}

else if($flag==8){
  $id=$_REQUEST['Rid'];
  $sql="UPDATE `hRecipes` SET `Approved`='true' WHERE `Recipe_ID`=".$id;
   $result = mysqli_query($conn, $sql);
    $sql1="SELECT * FROM `hDietician_Enrollment` where Dt_Userid='".$_SESSION['userid']."'";
    $result3=mysqli_query($conn,$sql1);
    $rowP=mysqli_fetch_assoc($result3);
    $pen=json_decode($rowP['Dt_PendingApproval']);
    
    $key = array_search($id, $pen);
    unset($pen[$key]);
  $pen = array_values($pen);
    $pen=json_encode($pen);
    $sql="UPDATE `hDietician_Enrollment` SET `Dt_PendingApproval` ='".$pen."' WHERE `Dt_Userid`='". $_SESSION['userid']."'";
     $result2=mysqli_query($conn,$sql);
   if(!$result){
   echo "Try again, Error";
   }
   else if(!$result2){
   echo "Try again, Error";
   }
    else if(!$result3){
   echo "Try again, Error";
   }
   else
   {
    echo "Approved";
   }
   
   
  

}

else if($flag==9){
  ini_set("auto_detect_line_endings", true);
  $er=0;
  $cnt=0;
  
 if(isset($_FILES["csv"])){
    
    $filename=$_FILES["csv"]["tmp_name"];   
    

     if($_FILES["csv"]["size"] > 0)
     {
        $file = fopen($filename, "r");
        
        
          while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
           { 
            $cnt++;
               if($cnt==1)
           continue;
          
                     $sql="INSERT INTO `hRecipe_Steps`( `Rid`, `steps`) VALUES ('".$getData[0]."' ,'".$getData[2]."')";
                     $result = mysqli_query($conn, $sql);
                   
        if(!$result)
        {
            $er=1;    
        }
        
        
           }
      
           fclose($file); 
     }
     else{
  
      echo "Error,file not uploaded"  ; 
      $er=1;
      }
      
      
      
  }
  else{
  
  $er=1;
  }
  
  
  if($er==1)
  {
   
   echo "Error,Steps file not uploaded. Check CSV";
  
  }
  else
  { 
   echo "Steps Uploaded, ".$cnt." rows afftected";
  }
  
  
}
else if($flag==10){
   $Aid=$_REQUEST['Aid'];
    $nm=$_REQUEST['nm'];
        $age=$_REQUEST['age'];
        $gen=$_REQUEST['gen'];
        $sts=$_REQUEST['sts'];
        $email=$_REQUEST['email'];
        $asDiet=$_REQUEST['asDiet'];
$note=$_REQUEST['note'];
$notedate=$_REQUEST['notedate'];
       $pno=$_REQUEST['pno'];
        $apno=$_REQUEST['apno'];
     
  $addr=$_REQUEST['addr'];
        $state=$_REQUEST['state'];
$city=$_REQUEST['city'];
        
        $chk=$_REQUEST['chk'];
        $chkAll=$_REQUEST['chkAll']; 
      $str="INSERT INTO `hMem_Health_Demo`(`member_id`, `seq`, `measure_type`, `measure_date`, `measure_val`) VALUES ";  
       $arrH=json_decode($_REQUEST['arrH']);
    
     $usr=$email;
 $pwd= rand();
echo "password is ".$pwd." ,";
$x=0;
for($i=0;$i<sizeof($arrH)/3;$i++)
     {     
    $sql="SELECT * FROM `hMem_Health_Demo` WHERE `member_id`='{$usr}' and `measure_type`='{$arrH[$x+1]}' ";
    $resultmp = mysqli_query($conn, $sql);
if(mysqli_num_rows($resultmp)>0)
      $seq=mysqli_num_rows($resultmp)+1;
else
      $seq=1;

      $str1="('{$usr}','{$seq}','{$arrH[$x+1]}','{$arrH[$x]}','{$arrH[$x+2]}')";
    
mysqli_query($conn,$str.$str1);
    $x+=3;
     }

 //$resulth = mysqli_query($conn, $str);

    $sql1="INSERT INTO `hAuthentication` (`Auth_UserID`, `Auth_Password`, `Auth_Roleid`, `Auth_Denyaccess`) VALUES ('".$usr."','".encryptIt($pwd)."','M','1')";
    $result1 = mysqli_query($conn, $sql1);
    
   
    $msg = "<html><body><center><h1>Hey Member, Your UserName and Password are here..</h1></center><br><br><br><center> <b>Username: <u>".$usr."</u><br><br>Password: <u>".$pwd."</u></b></center></body></html>";
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  mail($email,"Welcome Member, Yours Credentials are here",$msg,$headers);
       
  $sql="INSERT INTO `hMember_Demo`( `Ast_AuthId`, `Mb_Name`, `Mb_Age`, `Mb_Gen`, `Mb_Status`, `Mb_Email`, `Dt_AuthID`, `Created_By`, `Created_Date`, `Modified_By`, `Modified_Date`, `userid`, `memuserid`, `Phoneno`, `AltPhoneno`, `Address`, `State`, `City`) VALUES ('".$Aid."','".$nm."','".$age."','".$gen."','".$sts."','".$email."','".$asDiet."','".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."','".$usr."','".$pno."','".$apno."','".$addr."','".$state."','".$city."')";
      
       
     
         $result = mysqli_query($conn, $sql);

          $M_id = mysqli_insert_id($conn);
          
          
          
          $sql="INSERT INTO `Mem_Diet_Pref`( `Mid`, `Mem_pref`, `allergy_pref`, `Created_By`, `Created_Date`, `Modified_by`, `Modified_date`) VALUES ('". $M_id."','". $chk."','". $chkAll."','".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."',CURDATE())";
          
           $result2 = mysqli_query($conn, $sql);
         
$sql="INSERT INTO `hMember_Notes`(`Mb_date`, `Mb_Note`, `Mb_Id`) VALUES ('{$notedate}','{$note}','{$M_id}')";
           $resultnot = mysqli_query($conn, $sql);
  /*        $sql="INSERT INTO `Mem_Health_Cond`( `Record_Date`, `Height`, `Weight`, `Waist`, `Chest`, `Sugar_Levels`, `Blood_Pressure`, `Lipid_Profile`, `Thyroid`, `Taken_by`, `Created_By`, `Created_Date`, `Modified_by`, `Modified_date`, `Member_Id`) VALUES ('".$rhd."','".$rht."','".$rwt."','".$rwa."','".$rch."','".$rsl."','".$rbp."','".$rlp."','".$rt."','".$rtb."','".$rhcb."','".$rhcd."','".$rhmb."','".$rhmd."','". $M_id."')";
          
           $result3 = mysqli_query($conn, $sql);
      */     
          


 
 if (!$result)
 echo mysqli_error($conn);
          
     
         if(!$result)
         {
           echo "error1 ".mysqli_error($conn);
         }   
         else  if(!$result2)
         {
           echo "error2 ".mysqli_error($conn);
         }
    else if(!$resultnot){
        echo "error3 ".mysqli_error($conn);
        }
         else
          echo "Member submitted";

          if ($result1)
{
echo ", Member Credentials have been sent. Check email.";
}
 else
 echo mysqli_error($conn);

}
else if($flag=='memsrc'){
$str=$_REQUEST['memsrc'];
   $sql="select * from hDietician_Enrollment where Dt_Userid='".$_SESSION['userid']."'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);


    $sql= "SELECT Mb_ID, Mb_Name, Mb_Age, Mb_Gen FROM hMember_Demo where Dt_AuthID='".$row['Dt_AuthID']."' and Mb_Name like '".$str."%'";
$res=mysqli_query($conn,$sql);
   if(mysqli_num_rows($res)>0)
{$cnt=0;
    while($row=mysqli_fetch_assoc($res))
     {
       echo "<tr onclick=\"$('#check"  .$cnt. "').click();\" >
                  <td> <input type='checkbox' id='check". $cnt++."' class='checkbox-template' name=''></td>
                <td>".  $row['Mb_Name']."</td>
                <td>".  $row['Mb_Age']."</td>
    <td>". $row['Mb_Gen']."</td>

      <td><button class='btn btn-light' onclick='event.stopPropagation(); Upmem(". $row['Mb_ID'] .") ' >Update</button></td>
        </tr>";
    
      }

      }

}

else if($flag=='updatememfinal'){


$Aid=$_REQUEST['Aid'];
$note=$_REQUEST['note'];
$notedate=$_REQUEST['notedate'];
$mid=$_REQUEST['mid'];
    $nm=$_REQUEST['nm'];
        $age=$_REQUEST['age'];
        $gen=$_REQUEST['gen'];
        $sts=$_REQUEST['sts'];
 $pno=$_REQUEST['pno'];
 $apno=$_REQUEST['apno'];
 $addr=$_REQUEST['addr'];
 $city=$_REQUEST['city'];
 $state=$_REQUEST['state'];
        $email=$_REQUEST['email'];
        $asDiet=$_REQUEST['asDiet'];
        $chk=$_REQUEST['chk'];    
        $chkAll=$_REQUEST['chkAll']; 
      $str="INSERT INTO `hMem_Health_Demo`(`member_id`, `seq`, `measure_type`, `measure_date`, `measure_val`) VALUES ";  
       $arrH=json_decode($_REQUEST['arrH']);
    
     $usr=$email;

$x=0;
for($i=0;$i<sizeof($arrH)/3;$i++)
     {     
    $sql="SELECT * FROM `hMem_Health_Demo` WHERE `member_id`='{$usr}' and `measure_type`='{$arrH[$x+1]}' ";
    $resultmp = mysqli_query($conn, $sql);
if(mysqli_num_rows($resultmp)>0)
      $seq=mysqli_num_rows($resultmp)+1;
else
      $seq=1;

      $str1="('{$usr}','{$seq}','{$arrH[$x+1]}','{$arrH[$x]}','{$arrH[$x+2]}')";
    
mysqli_query($conn,$str.$str1);
    $x+=3;
     }

 //$resulth = mysqli_query($conn, $str);

  $sql="UPDATE `hMember_Demo` SET `Ast_AuthId`='{$Aid}',`Mb_Name`='{$nm}',`Mb_Age`='{$age}',`Mb_Gen`='{$gen}',`Mb_Status`='{$sts}',`Mb_Email`='{$email}',`Dt_AuthID`='{$asDiet}', `Modified_By`='{$_SESSION['userid']}', `Modified_Date`=CURDATE() ,`Address`='{$addr}',`Phoneno`='{$pno}',`AltPhoneno`='{$apno}',`State`='{$state}',`City`='{$city}' where `Mb_ID`='{$mid}'";
 /*      
  $sql="INSERT INTO `hMember_Demo`( `Ast_AuthId`, `Mb_Name`, `Mb_Age`, `Mb_Gen`, `Mb_Status`, `Mb_Email`, `Dt_AuthID`, `Created_By`, `Created_Date`, `Modified_By`, `Modified_Date`, `userid`, `memuserid`) VALUES ('".$Aid."','".$nm."','".$age."','".$gen."','".$sts."','".$email."','".$asDiet."','".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."','".$usr."')";
   */   
       
     
         $result = mysqli_query($conn, $sql);
   
        
          
          $sql="UPDATE `Mem_Diet_Pref` SET `Mem_pref`='{$chk}',`allergy_pref`='{$chkAll}',`Modified_by`='{$_SESSION['userid']}',`Modified_date`=CURDATE() where `Mid`='{$mid}'";
          
          
           $result2 = mysqli_query($conn, $sql);
   
         $sql="INSERT INTO `hMember_Notes`(`Mb_date`, `Mb_Note`, `Mb_Id`) VALUES ('{$notedate}','{$note}','{$mid}')";
           $resultnot = mysqli_query($conn, $sql);
   
         if(!$result)
         {
           echo "error1 ".mysqli_error($conn);
         }   
         else  if(!$result2)
         {
           echo "error2 ".mysqli_error($conn);
         }
 		else  if(!$resultnot)
         {
           echo "error3 ".mysqli_error($conn);
         }
         else
          echo "Member Updated";



}


else if($flag=='upmem') {


$id=$_REQUEST['id'];
  $sql="select * from hMember_Demo where Mb_ID = '".$id."'";
$res=mysqli_query($conn,$sql);
$data=array();
$tmp=array();
while($r=mysqli_fetch_assoc($res))
{
  array_push($tmp,$r);
}
array_push($data,$tmp);



/*  $sql="select * from Mem_Health_Cond where Member_Id = '".$id."'";
$res=mysqli_query($conn,$sql);
$tmp=array();
while($r=mysqli_fetch_assoc($res))
{
  array_push($tmp,$r);
}
array_push($data,$tmp);
*/

  $sql="select * from Mem_Diet_Pref where Mid = '".$id."' order by Created_Date desc limit 1 ";
$res=mysqli_query($conn,$sql);
$tmp=array();
while($r=mysqli_fetch_assoc($res))
{
  array_push($tmp,$r);
}
array_push($data,$tmp);

array_push($data,"true");
$_SESSION['memupflag']=1;
$_SESSION['memuparr']=$data;
echo json_encode($data);
}
else if ($flag=='assignmem') {
  $Did=$_REQUEST['Did'];
  $car=$_REQUEST['car'];
   $arr=json_decode($car);
   for ($i=0; $i < sizeof($arr); $i++) { 
      $sql="update hMember_Demo set Dt_AuthID='".$Did."' where Mb_ID='".$arr[$i]."'";
      $r=mysqli_query($conn,$sql);
      if ($r) {
        echo "true";
      }
      else{
        echo $arr[$i]."false".$sql;
      }
   }
}

else if ($flag=='dietPlan') {
  $mn=$_REQUEST['mn'];
  $mt=$_REQUEST['mt'];
  $dId=$_REQUEST['dId'];
  $rid=$_REQUEST['rid'];
   $pn=$_REQUEST['pn'];
 $pd=$_REQUEST['pd'];
 $mid=$_REQUEST['mid'];
 $rq=$_REQUEST['rq'];
  $sql="Select * from hDietPlans";

  if($dId==0){
    $res=mysqli_query($conn,$sql);  
  
  if(mysqli_num_rows($res)>0){
    //diet plan exists
    $sql="select max(DietPlanId) as ans from hDietPlans";
  $res=mysqli_query($conn,$sql);
  $r=mysqli_fetch_assoc($res);
  $dpId=$r['ans']+1;
  
  }
  else
    $dpId=1;
}
else
$dpId=$dId;


if ($dId==0) {
   $seq=1;
}
else
{
   $sql="select max(Seq) as s from hDietPlans where DietPlanId='".$dpId."'";
  $res=mysqli_query($conn,$sql);
  $r=mysqli_fetch_assoc($res);
  $seq=$r['s']+1;
}

$arr=array();
array_push($arr,$dpId);

if($seq==1){


$sql="select max(Seq) as s from hMemDietPlan where Member_Id={$mid}";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0){
$r=mysqli_fetch_assoc($res);
$sq=$r['s']+1;
}
else{
  $sq=1;
}

$sql="INSERT INTO `hMemDietPlan`(`Member_Id`, `Seq`, `Plan_Date`, `Primary_Dt_AuthID`, `Reviewer_Dt_AuthID`, `Diet_Plan_Id`, `Product_Id1`, `Product_Id2`, `Product_Id3`, `Dt_Notes`, `Created_By`, `Created_Date`, `Modified_by`, `Modified_date`) VALUES ('".$mid."','".$sq."','".$pd."','".$_SESSION['userid']."','".$_SESSION['userid']."','".$dpId."','','','','notes','".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."',CURDATE())";

$res=mysqli_query($conn,$sql);

} 


 $sql="INSERT INTO `hDietPlans`(`DietPlanId`,`PlanName`, `Seq`, `MealName`, `MealTime`, `RecipeID`, `Quantity`) VALUES ('".$dpId."','".$pn."','".$seq."','".$mn."','".$mt."','".$rid."','".$rq."')";
  $r=mysqli_query($conn,$sql);
  if($r&&$res){
  array_push($arr,"Success");    

  }
  else{
    array_push($arr,"Failure");
  }
  $last_id = mysqli_insert_id($conn);   
$sql="Select * from hRecipes where Recipe_ID='".$rid."'";
$r=mysqli_query($conn,$sql);
$ro=mysqli_fetch_assoc($r);
array_push($arr,$ro['Recipe_Pic']);
array_push($arr,$ro['Recipe_Name']);
array_push($arr,$last_id);

  echo json_encode($arr);


}
else if($flag=='dietPlanView'){
$f=$_REQUEST['f'];
if($f==1)
{
	$_SESSION['dietplanview']=" ";
}

 $realCardCount=0;
 $arr=array();
$totQ=0;
 $mid=$_REQUEST['mid'];
if($mid=='all')
{
	if($f==1){
	$sql="select * from hMemDietPlan where Primary_Dt_AuthID='{$_SESSION['userid']}' order by Seq desc limit 10";
	}
	else
	$sql="select * from hMemDietPlan  where `Diet_Plan_Id` not in (".substr($_SESSION['dietplanview'],0,-1).") and Primary_Dt_AuthID='{$_SESSION['userid']}' order by Seq desc limit 7";
}
 else
{
    if($f==1){
	$sql="select * from hMemDietPlan where Member_Id='".$mid."' order by Seq desc limit 10";	
	}
	else
	$sql="select * from hMemDietPlan  where  Member_Id='".$mid."' and  `Diet_Plan_Id` not in (".substr($_SESSION['dietplanview'],0,-1).") order by Seq desc limit 7";

}
$res=mysqli_query($conn,$sql);
 $arrtosend=array();
 $arr1=array();
$str="";
 $cntDiet=0;  
if(mysqli_num_rows($res)){
   
    while ($r=mysqli_fetch_assoc($res)) {
       $cardCount=0;
       $cntDiet++;
$totQ=0;
      $str.="<div class='project' id='Diet".$cntDiet."'  onclick='toggle(&quot;PlanDetail".$cntDiet."&quot;)' style=' transition: all 0.3s cubic-bezier(.25,.8,.25,1);'>
                <div class='row bg-white has-shadow'>
                  <div class='left-col col-lg-6 d-flex align-items-center justify-content-between'>
                    <div class='project-title d-flex align-items-center'>
                      <div class='text'>
                        <h3 class='h4 DietName' id='DietName".$cntDiet."'  ></h3><small>Owner Dietician ".$r['Primary_Dt_AuthID']."</small>
                      </div>
                    </div>
                    <div class='project-date'><span class='hidden-sm-down'><span style='color:orange'>".$r['Plan_Date']."</span></span></div>
                  </div>
                  <div class='right-col col-lg-6 d-flex align-items-center'>
                    <div class='time'><i class='fas fa-balance-scale'></i><span id='Q".$cntDiet."'>300 </span>Kcal </div>
                    <div class='comments'><i class='far fa-comments'></i>20</div>
                    <div class='d-flex ' style='width:130px;justify-content:  space-evenly;'>
                  
<button style='border-radius: 50%;color: grey;' id='cpybtn".$cntDiet."' class='btn btn-light has-shadow' ><i class='far fa-copy'></i></button>
    
<button style='padding:5px;border-radius: 50%;color: grey;' id='sharebtn".$cntDiet."' class='btn btn-light  has-shadow' ><i class='far fa-share-square'></i></button>
                    </div>
                  </div>
                 <div style='display:none;' class='accord' id='PlanDetail".$cntDiet."'>

                  ";
                    $did=$r['Diet_Plan_Id'];
    				$_SESSION['dietplanview'].="'{$did}',";
                     $strf="";
      $strl="";
      $strm="";
      $mealtemp="";
      $meal="";
      $fin="";
                $sq="Select * from hDietPlans where DietPlanId='".$did."' order by MealName desc";
                $rs=mysqli_query($conn,$sq);
                if(mysqli_num_rows($rs)>0){
                     while($ro=mysqli_fetch_assoc($rs)){
                                          if($cardCount==0)
                           {$meal=$ro['MealName'];
                            $mealtemp=$meal;
                            }
                          
                    $mealtemp=$ro['MealName'];
                  if($mealtemp!=$meal)
                  {

                  $fin.= $strf.$strm.$strl;
                  }
                          if($cardCount==0||$mealtemp!=$meal){
                    $strm="";
                           $meal=$mealtemp;
                            $cardCount++;
                            $realCardCount++;
                               
                            $strf="<script>$('#cpybtn".$cntDiet."').attr('onclick','event.stopPropagation();copyPlan(".$ro['DietPlanId'].");');$('#sharebtn".$cntDiet."').attr('onclick','event.stopPropagation();sharePlan(".$ro['DietPlanId'].");'); $('#DietName".$cntDiet."').html('".$ro['PlanName']."')</script><form  id='frm". $realCardCount."'  data-mealName='".$ro['MealName']."'  data-mealtime='".$ro['MealTime']."' data-dietId='".$ro['DietPlanId']."' data-planDate='".$r['Plan_Date']."' data-planName='".$ro['PlanName']."' style='display: inline-block;' class='ng-pristine ng-valid'><div   class='card card2' ><div class='card-body'><input name='7th' type='hidden'><h2 class='card-title'>".$ro['MealName']."</h2><small>".$ro['MealTime']."</small></div><div class='card-img-bottom' id='cardimg".$realCardCount."'><div class='addrecipe mb-3' onclick='event.stopPropagation(); addingRecipe(".$realCardCount.");chngcolor(".$realCardCount.");' style=' color:lightgray ;    padding: 5px;border: 3px dashed lightgray;'><i class='fas fa-plus'></i> Add Here</div>";

                            $strl="</div></div></form>";
                            }

$sql="Select * from hRecipes where Recipe_ID='".$ro['RecipeID']."'";
$rx=mysqli_query($conn,$sql);
$re=mysqli_fetch_assoc($rx);
  $totQ=$totQ+ (int)$re['Energy_Kcal'];
$strm.="<div class='mb-3 has-shadow recadded' style=' ' data-recid='{$ro['RecipeID']}'><div style='width:50px; height:50px;' class='has-shadow' ><img  src='' data-img='{$re['Recipe_Pic']}' class='loadimg img-fluid'/></div><div style=''> <div class='text'><h3 class='h4'>".$re['Recipe_Name']."</h3><strong style='color: #aaa;font-size: 0.75em;'><i class='fas fa-balance-scale'></i>   {$ro['Quantity']}</strong></div></div><div class='close' onclick='event.stopPropagation();deleteRecipe({$ro['id']},this)'><i class='icon-close'></i></div></div>";
                      
                           
                          }

                        $fin.=$strf.$strm.$strl;

                     }
                     $str.="<form  style='display: inline-block;' class='ng-pristine ng-valid'  >
<div class='card card2 card21' id=''   onclick='event.stopPropagation(); $(&quot;#modalMeal&quot;).modal(); $(&quot;#modalMeal&quot;).attr(&quot;data-calledfrom&quot;,&quot;".$cntDiet."&quot;); $(&quot;#modalMeal&quot;).attr(&quot;data-dietid&quot;,&quot;".$did."&quot;);$(&quot;#modalMeal&quot;).attr(&quot;data-dietdate&quot;,&quot;".$r['Plan_Date']."&quot;)'>
<div class='card-body'><input name='6th' type='hidden' >
<h2 class='card-title'>Add Meal</h2>
<small>Add new Meal plan</small>
</div>
<div class='card-img-bottom' style='border:5px dashed lightgray;'>
 <i id='onei' class='fas fa-plus' style='    
    position: relative; 
    top: 50%;
    color:lightgray;
    left: 50%;
    transform: translate(-50%,-50%);
    font-size: 70px;'></i>
</div>


</div>
</form>".$fin;

                   $str.="
                 </div>
                <script>$('#Q".$cntDiet."').html('".$totQ."');</script>
              </div>
   </div>";
                   }


                 }
               

array_push($arr,$str);
array_push($arr,$realCardCount);
array_push($arr,$cntDiet);
echo json_encode($arr);
}
else if($flag=='memdietPlanView'){
 $realCardCount=0;
 $arr=array();
$totQ=0;
 $mid=$_REQUEST['mid'];
if($mid=='all')
$sql="select * from hMemDietPlan order by Seq desc";
else
$sql="select * from hMemDietPlan where Member_Id='".$mid."' order by Seq desc";
 $res=mysqli_query($conn,$sql);
 $arrtosend=array();
 $arr1=array();
$str="";
  if(mysqli_num_rows($res)){
    $cntDiet=0;
    while ($r=mysqli_fetch_assoc($res)) {
       $cardCount=0;
       $cntDiet++;
$totQ=0;
      $str.="<div class='project' id='Diet".$cntDiet."'  onclick='toggle(&quot;PlanDetail".$cntDiet."&quot;)' style=' transition: all 0.3s cubic-bezier(.25,.8,.25,1);'>
                <div class='row  has-shadow' style='background-color:#eee;'>
                  <div class='left-col col-lg-6 d-flex align-items-center justify-content-between'>
                    <div class='project-title d-flex align-items-center'>
                      <div class='text'>
                        <h3 class='h4 DietName' id='DietName".$cntDiet."'  ></h3><small>Owner Dietician ".$r['Primary_Dt_AuthID']."</small>
                      </div>
                    </div>
                    <div class='project-date'><span class='hidden-sm-down'><span >".$r['Plan_Date']."</span></span></div>
                  </div>
                  <div class='right-col col-lg-6 d-flex align-items-center'>
                    <div class='time'><i class='fas fa-balance-scale'></i><span id='Q".$cntDiet."'>300 </span>Kcal </div>
                   
                  </div>
                 <div style='display:none; width:100%;' class='accord' id='PlanDetail".$cntDiet."'>
                      <table class='table table-hover' style='text-align:center;background:white;'>
              <thead>
               <th> Meal</th>
                <th>Time</th>
                <th>Recipe</th>
                <th>Quantity</th>
                <th>Preparation</th>
                

              </tr></thead>
               <tbody>

                  ";
                    $did=$r['Diet_Plan_Id'];
                     $strf="";
      $strl="";
      $strm="";
      $mealtemp="";
      $meal="";
      $fin="";
                $sq="Select * from hDietPlans where DietPlanId='".$did."' order by MealName desc";
                $rs=mysqli_query($conn,$sq);
                if(mysqli_num_rows($rs)>0){
                     while($ro=mysqli_fetch_assoc($rs)){
                                          if($cardCount==0)
                           {$meal=$ro['MealName'];
                            $mealtemp=$meal;
                            }
                          
                    $mealtemp=$ro['MealName'];
                  if($mealtemp!=$meal)
                  {

                  $fin.= $strf.$strm.$strl;
                  }
                          if($cardCount==0||$mealtemp!=$meal){
                    $strm="";
                           $meal=$mealtemp;
                            $cardCount++;
                            $realCardCount++;
                               
                        /*    $strf="<script>$('#cpybtn".$cntDiet."').attr('onclick','event.stopPropagation();copyPlan(".$ro['DietPlanId'].");');$('#sharebtn".$cntDiet."').attr('onclick','event.stopPropagation();sharePlan(".$ro['DietPlanId'].");'); $('#DietName".$cntDiet."').html('".$ro['PlanName']."')</script><form  id='frm". $realCardCount."'  data-mealName='".$ro['MealName']."'  data-mealtime='".$ro['MealTime']."' data-dietId='".$ro['DietPlanId']."' data-planDate='".$r['Plan_Date']."' data-planName='".$ro['PlanName']."' style='display: inline-block;' class='ng-pristine ng-valid'><div   class='card card2' ><div class='card-body'><input name='7th' type='hidden'  value='More On Class 9th-10th'><h2 class='card-title'>".$ro['MealName']."</h2><small>".$ro['MealTime']."</small></div><div class='card-img-bottom' id='cardimg".$realCardCount."'><div class='addrecipe mb-3' onclick='event.stopPropagation(); addingRecipe(".$realCardCount.");chngcolor(".$realCardCount.");' style=' color:lightgray ;    padding: 5px;border: 3px dashed lightgray;'><i class='fas fa-plus'></i> Add Here</div>";
                          */
                         

                         //   $strl="";
                            }

$sql="Select * from hRecipes where Recipe_ID='".$ro['RecipeID']."'";
$rx=mysqli_query($conn,$sql);
$re=mysqli_fetch_assoc($rx);
  $totQ=$totQ+ (int)$re['Energy_Kcal'];
/*$strm.="<div class='mb-3 has-shadow recadded' style=' ' data-recid='{$ro['RecipeID']}'><div style='width:50px; height:50px;' class='has-shadow' ><img  src='".$re['Recipe_Pic']."' class='img-fluid'/></div><div style=''> <div class='text'><h3 class='h4'>".$re['Recipe_Name']."</h3><strong style='color: #aaa;font-size: 0.75em;'><i class='fas fa-balance-scale'></i>   {$ro['Quantity']}</strong></div></div><div class='close' onclick='event.stopPropagation();deleteRecipe({$ro['id']},this)'><i class='icon-close'></i></div></div>";
                   */   
         $strm.="<tr><td>{$ro['PlanName']}</td><td>{$ro['MealTime']}</td><td>{$re['Recipe_Name']}</td><td>{$ro['Quantity']}</td><td style='display: flex;justify-content: center;'><button class='btn btn-primary recadded' data-recid='{$ro['RecipeID']}'  >Preparation</button></td></tr>";                  
                          }

                        $fin.=$strm;

                     }
                     $str.=$fin;

                   $str.="
                    </tbody>
            </table>
                 </div>
                <script>$('#Q".$cntDiet."').html('".$totQ."');</script>
              </div>
   </div>";
                   }


                 }
               

array_push($arr,$str);
array_push($arr,$realCardCount);
array_push($arr,$cntDiet);
echo json_encode($arr);
}
else if($flag=='deleteRecipefromplan'){
  $id=$_REQUEST['id'];

$sql='delete from hDietPlans where id='.$id;

$rs=mysqli_query($conn,$sql);
if($rs){
  echo 1;
}
else{
  echo 0;
}

}
else if($flag=='recipelist'){
$chk=$_REQUEST['chk'];
     $sql="select * from hRecipes where Userid='".$_SESSION['userid']."'";
    $result2=mysqli_query($conn,$sql);

 if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  $Rprop=json_decode($row2['Properties']);
        
          $ch=json_decode($chk);
          $i=0;$flag=0;$flag2=0;

 
$i=0;
          foreach ($Rprop as $k) {
            if(($ch[$i]==$k)&&($ch[$i]==1)){
              $flag=1;
              $i++;
            }
          }
          if($flag!=1){
            continue;
          }
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
           $RtempId=$row2['Recipe_ID'];
  
echo "
<div class='project row bg-white has-shadow mb-3'>
                  <div class='d-flex align-items-center' style='width:100%;'>
<div class='project-title d-flex align-items-center' style='width:100%;'>
                      <div class='image has-shadow'><img onclick='event.stopPropagation(); openOverlay(this)' src='".$Rtemppc."'  class='img-fluid'></div>
                      <div class='text' style='padding-left:10px;'>
                        <h3 class='h4'>". $Rtempnm ."
</h3><small>Id ". $RtempId."</small>
</div>
<div style='padding-left:15px;'>
<button class='btn btn-light has-shadow' style='border-radius:50%;font-size: 10px;
    padding: 5px;
    border-radius: 50%;' onclick='addmeRecipe(".$RtempId.")'><i  class='fas fa-plus'></i></button>
                      </div>
                   
                 
                  </div>

</div>
              </div>
";

}

}

}
else if($flag=='reclistsrc'){
$chk=$_REQUEST['srcrec'];
     $sql="select * from hRecipes where Recipe_Name like '".$chk."%' and Approved='true'  limit 7";
    $result2=mysqli_query($conn,$sql);

 if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
           $RtempId=$row2['Recipe_ID'];
  
echo "
<div class='project row bg-white has-shadow mb-3'>
                  <div class='d-flex align-items-center' style='width:100%;'>
<div class='project-title d-flex align-items-center' style='width:100%;'>
                      <div class='image has-shadow'><img onclick='event.stopPropagation(); openOverlay(this)' src='".$Rtemppc."'  class='img-fluid'></div>
                      <div class='text' style='padding-left:10px;'>
                        <h3 class='h4'>". $Rtempnm ."
</h3><small>Id ". $RtempId."</small>
</div>
<div style='padding-left:15px;'>
<button class='btn btn-light has-shadow' style='border-radius:50%;font-size: 10px;
    padding: 5px;
    border-radius: 50%;' onclick='addmeRecipe(".$RtempId.")'><i  class='fas fa-plus'></i></button>
                      </div>
                   
                 
                  </div>

</div>
              </div>
";

}

}

}
else if($flag=='copyplan'){
$pid=$_REQUEST['planid'];
$mid=$_REQUEST['mid'];
$pd=$_REQUEST['pd'];


$sql="select max(Seq) as s from hMemDietPlan where Member_Id='"+$mid+"'";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0){
$r=mysqli_fetch_assoc($res);
$sq=$r['s']+1;
}
else{
  $sq=1;
}

$sql="INSERT INTO `hMemDietPlan`(`Member_Id`, `Seq`, `Plan_Date`, `Primary_Dt_AuthID`, `Reviewer_Dt_AuthID`, `Diet_Plan_Id`, `Product_Id1`, `Product_Id2`, `Product_Id3`, `Dt_Notes`, `Created_By`, `Created_Date`, `Modified_by`, `Modified_date`) VALUES ('".$mid."','".$sq."','".$pd."','".$_SESSION['userid']."','".$_SESSION['userid']."','".$pid."','','','','notes','".$_SESSION['userid']."',CURDATE(),'".$_SESSION['userid']."',CURDATE())";

$res=mysqli_query($conn,$sql);

if ($res) {
 echo 1;
}
else{
  echo 0;
}

}
  else if($flag=='memdetail'){
$mid=$_REQUEST['mid'];
   
if($mid!='all')
{$result = mysqli_query($conn,"SELECT * FROM `hMember_Demo` where Mb_ID=".$mid);

    while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){

    echo "    <table class='table text-center'>
        <tr>
        <td><span> <b>Name</b></span></br> {$row['Mb_Name']}</td>
        </tr>
        <tr>
        <td> <span> <b>Age</b></span></br>  {$row['Mb_Age']}     </td>
        </tr>
         <tr>
        <td><span> <b>Gender</b></span></br>  {$row['Mb_Gen']}</td>
         </tr>
        <tr>
        <td><span> <b>Email</b></span></br>  {$row['Mb_Email']}  </td>
        </tr>
        ";

    }
    $adpref=array();
     $alpref=array();

  $sql1="SELECT * FROM `hGen_Diet_Pref` ORDER by `Dp_Id`";
   $res1=mysqli_query($conn,$sql1);
    while($row = mysqli_fetch_assoc($res1)){
    array_push($adpref,$row['Dp_name']);
    }
  
   $sql2="SELECT * FROM `hGen_Allergiesf` ORDER BY `Al_Id`";
   $res2=mysqli_query($conn,$sql2);
    while($row = mysqli_fetch_assoc($res2)){
    array_push($alpref,$row['Al_name']);
    }
  
  
$sql="SELECT * FROM `Mem_Diet_Pref` WHERE `Mid`='{$mid}' order by `Modified_date` desc limit 1";
  $res=mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)>0){
  $r=mysqli_fetch_assoc($res);
    $dpref=json_decode($r['Mem_pref']);
    $apref=json_decode($r['allergy_pref']);
  
  echo "<tr><td><span> <b>Diet Pref</b></span></td></tr>";

for ($i=0; $i < sizeof($adpref); $i++) { 
  if($dpref[$i]=="true")
    echo "<tr><td>".$adpref[$i]."</td></tr>";
}
  echo "<tr><td><span> <b>Allergies</b></span></td></tr>";
for ($i=0; $i < sizeof($alpref); $i++) { 
  if($apref[$i]=="true")
    echo "<tr><td>".$alpref[$i]."</td></tr>";
}

  }
$sql="SELECT `memuserid` FROM `hMember_Demo` WHERE `Mb_ID`='{$mid}'";
$res=mysqli_query($conn,$sql);
$r=mysqli_fetch_assoc($res);
$memid=$r['memuserid'];

   $sql="SELECT `measure_type`,`measure_val` FROM `hMem_Health_Demo` WHERE member_id='{$memid}' and id in (SELECT max(id) FROM hMem_Health_Demo where `member_id`='{$memid}' GROUP by `measure_type`)";
                                        $rs=mysqli_query($conn,$sql);
                                        while ($r=mysqli_fetch_assoc($rs)) {

                                          $s="SELECT `description` FROM `hGen_Health_Demo` WHERE `measure_type`='{$r['measure_type']}'";
                                          $res=mysqli_query($conn,$s);
                                          $ro=mysqli_fetch_assoc($res);
                                          $des=$ro['description'];
                                          echo "<tr><td><span><b>{$des}</b></span></td></tr><tr><td>{$r['measure_val']}</td></tr>";
                                        }
  
echo "</table>";
}
  
  }
  else if($flag=='memrecview'){
  $rid=$_REQUEST['rid'];
   $sql="select * from hRecipes where Recipe_ID='".$rid."'";
  $result2=mysqli_query($conn,$sql);
  $tos=array();
   if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  
        array_push($tos,$row2['Recipe_Name']);
        array_push($tos,$row2['Recipe_Pic']);
        array_push($tos,$row2['Energy_Kcal']);
        array_push($tos,$row2['Approved']);
        
        array_push($tos,$row2['Energy_Kcal']);
        array_push($tos,$row2['Fats']);
        array_push($tos,$row2['Carbohydrate']);
        array_push($tos,$row2['Protein']);
        array_push($tos,$row2['Fibre']);
        array_push($tos,$row2['Water']);
        array_push($tos,$row2['Unit_Of_Measure']);
        array_push($tos,$row2['Quantity']);
        array_push($tos,$row2['Properties']);
       
         $RtempId=$row2['Recipe_ID'];
         $sql= "SELECT * FROM `hRecipe_Steps` WHERE `Rid`='".$RtempId."' order by sno";
         $res=mysqli_query($conn,$sql);
         $stepstr=array();
        
          if(mysqli_num_rows($res)>0){
           while($r = mysqli_fetch_assoc($res))
           {
            array_push( $stepstr,$r['steps']);
           }
         }
          array_push($tos,$stepstr);
          $nm=array();
           $sql3="select * from hRecipe_Property";
  $result3=mysqli_query($conn,$sql3);
    while($row = mysqli_fetch_assoc($result3))
        {
          array_push($nm,$row['PropName']);
        }
         array_push($tos,$nm);

  }
  }
  
  echo json_encode($tos);
  }
else if($flag=='activemem'){

 $sql="select * from hDietician_Enrollment where Dt_Userid='".$_SESSION['userid']."'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);


    $sql= "SELECT Mb_ID, Mb_Name, Mb_Age, Mb_Gen FROM hMember_Demo where Dt_AuthID='".$row['Dt_AuthID']."' and Mb_Status='active'";
$res=mysqli_query($conn,$sql);
   if(mysqli_num_rows($res)>0)
{$cnt=0;
    while($row=mysqli_fetch_assoc($res))
     {
       echo "<tr onclick=\"$('#check"  .$cnt. "').click();\" >
                  <td> <input type='checkbox' id='check". $cnt++."' class='checkbox-template' name=''></td>
                <td>".  $row['Mb_Name']."</td>
                <td>".  $row['Mb_Age']."</td>
    <td>". $row['Mb_Gen']."</td>

      <td><button class='btn btn-light' onclick='event.stopPropagation(); Upmem(". $row['Mb_ID'] .") ' >Update</button></td>
        </tr>";
    
      }

      }


}
else if($flag=='allmem'){


 $sql="select * from hDietician_Enrollment where Dt_Userid='".$_SESSION['userid']."'";
  $result=mysqli_query($conn,$sql);
  $row=mysqli_fetch_assoc($result);


    $sql= "SELECT Mb_ID, Mb_Name, Mb_Age, Mb_Gen FROM hMember_Demo where Dt_AuthID='".$row['Dt_AuthID']."'";
$res=mysqli_query($conn,$sql);
   if(mysqli_num_rows($res)>0)
{$cnt=0;
    while($row=mysqli_fetch_assoc($res))
     {
       echo "<tr onclick=\"$('#check"  .$cnt. "').click();\" >
                  <td> <input type='checkbox' id='check". $cnt++."' class='checkbox-template' name=''></td>
                <td>".  $row['Mb_Name']."</td>
                <td>".  $row['Mb_Age']."</td>
    <td>". $row['Mb_Gen']."</td>

      <td><button class='btn btn-light' onclick='event.stopPropagation(); Upmem(". $row['Mb_ID'] .") ' >Update</button></td>
        </tr>";
    
      }

      }

}
else if($flag=='dietrecview1'){
$f=$_REQUEST['f'];
if($f==1)
{
	$_SESSION['dietrecview1']=" ";
}

if($f==1){
$sql="select * from hRecipes where Userid='{$_SESSION['userid']}' and Approved='true'  limit 15";
}
else
$sql="select * from hRecipes where Userid='{$_SESSION['userid']}' and Approved='true' and `Recipe_ID` not in (".substr($_SESSION['dietrecview1'],0,-1).") limit 7";

    $result2=mysqli_query($conn,$sql);

 if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  
   
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
           $RtempId=$row2['Recipe_ID'];
   $_SESSION['dietrecview1'].="'{$RtempId}',";
  
echo "<script type='text/javascript'>chkcnt++;</script>
<div class='project row bg-white has-shadow mb-3'>
                  <div class='d-flex align-items-center' style='width:100%;'>
<div class='project-title d-flex align-items-center' style='width:100%;'>
                      <div class='image has-shadow'><img onclick='event.stopPropagation(); openOverlay(this)' src='' data-img='{$Rtemppc}'  class='loadimg img-fluid'></div>
                      <div class='text' style='padding-left:10px;'>
                        <h3 class='h4'> {$Rtempnm}

</h3><small>Id {$RtempId}</small>
</div>
<div style='padding-left:15px;'>
<button class='btn btn-light has-shadow' style='border-radius:50%;font-size: 10px;
    padding: 5px;
    border-radius: 50%;' onclick='addmeRecipe({$RtempId})'><i  class='fas fa-plus'></i></button>
                      </div>
                   
                 
                  </div>

</div>
              </div>";

   
}

}


}
else if($flag=='dietrecview2'){
$f=$_REQUEST['f'];
if($f==1)
{
	$_SESSION['dietrecview2']=" ";
}

if($f==1){
$sql="select * from hRecipes where   Approved='true'  limit 15";
}
else
$sql="select * from hRecipes where  Approved='true' and `Recipe_ID` not in (".substr($_SESSION['dietrecview2'],0,-1).") limit 7";

    $result2=mysqli_query($conn,$sql);

 if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
           $RtempId=$row2['Recipe_ID'];
      $_SESSION['dietrecview2'].="'{$RtempId}',";
  
echo "<script type='text/javascript'>chkcnt++;</script>
<div class='project row bg-white has-shadow mb-3'>
                  <div class='d-flex align-items-center' style='width:100%;'>
<div class='project-title d-flex align-items-center' style='width:100%;'>
                      <div class='image has-shadow'><img onclick='event.stopPropagation(); openOverlay(this)' src='' data-img='{$Rtemppc}'  class='loadimg img-fluid'></div>
                      <div class='text' style='padding-left:10px;'>
                        <h3 class='h4'> {$Rtempnm}

</h3><small>Id {$RtempId}</small>
</div>
<div style='padding-left:15px;'>
<button class='btn btn-light has-shadow' style='border-radius:50%;font-size: 10px;
    padding: 5px;
    border-radius: 50%;' onclick='addmeRecipe({$RtempId})'><i  class='fas fa-plus'></i></button>
                      </div>
                   
                 
                  </div>

</div>
              </div>";

   
}

}


}
else if($flag=='recview'){

  $sql="select * from hRecipes where Userid='".$_SESSION['userid']."' and Recipe_ID not in (".substr($_SESSION['recview'],0,-1).") limit 7 ";
  $result2=mysqli_query($conn,$sql);

$Rtempid="";
  $Rtempnm="";
  $Rseltemp="";
    if(mysqli_num_rows($result2)>0){
   while( $row2 = mysqli_fetch_assoc($result2))
     {  
        $Rtempnm=$row2['Recipe_Name'];
         $Rtemppc=$row2['Recipe_Pic'];
         $Rtempen=$row2['Energy_Kcal'];
         $Rtempap=$row2['Approved'];
        
          $RtempEnK=$row2['Energy_Kcal'];
           $RtempFats=$row2['Fats'];
            $RtempCarbohydrate=$row2['Carbohydrate'];
             $RtempProtein=$row2['Protein'];
              $RtempFibre=$row2['Fibre'];
               $RtempWater=$row2['Water'];
               $RtempUofM=$row2['Unit_Of_Measure'];
               $RtempQ=$row2['Quantity'];
	         $RtempProp=$row2['Properties'];
       
         $RtempId=$row2['Recipe_ID'];
   
   $_SESSION['recview'].="'{$RtempId}',";
         $sql= "SELECT * FROM `hRecipe_Steps` WHERE `Rid`='".$RtempId."' order by sno ";
         $res=mysqli_query($conn,$sql);
         $stepstr=array();
        
          if(mysqli_num_rows($res)>0){
	         while($r = mysqli_fetch_assoc($res))
	         {
	         	array_push( $stepstr,$r['steps']);
	         }
         }
           $Rtempstep=$stepstr;







echo "
<div class='project'  id='{$RtempId}'  onclick=&quot;selectView('{$RtempId}')&quot; style=' transition: all 0.3s cubic-bezier(.25,.8,.25,1);'>
                <div class='row bg-white has-shadow'>
                  <div class='left-col col-lg-6 d-flex align-items-center justify-content-between'>
                    <div class='project-title d-flex align-items-center'>
                      <div class='image has-shadow'><img onclick='event.stopPropagation(); openOverlay(this)' src='' data-img='"; if($Rtemppc=='/') echo 'preview.jpg'; else echo $Rtemppc; echo "'  class='img-fluid loadimg'></div>
                      <div class='text'>
                        <h3 class='h4'>{$Rtempnm}</h3><small>{$Rtempen} Kcal</small>
                      </div>
                    </div>
                    <div class='project-date'><span class='hidden-sm-down'>"; if( $Rtempap == 'true') echo "<span style='color:lightgreen'>Approved</span>"; else echo "<span style='color:orange'>Approval pending</span>";  echo "</div>
                  </div>
                  <div class='right-col col-lg-6 d-flex align-items-center'>
                    <div class='time'><i class='fas fa-balance-scale'></i> ".$RtempQ." ".$RtempUofM."</div>
                    <div class='comments'><i class='far fa-comments'></i>20</div>
                    <div class='project-progress' style='width:130px;'>
                      <div class='progress'>
                        <div role='progressbar' style='width: 45%; height: 6px;' aria-valuenow='25' aria-valuemin='0' aria-valuemax='100' class='progress-bar bg-red'></div>
                      </div>
                    </div>
                   
                    <div >
                    <button class='btn btn-primary' id='RecipeEdit' onclick=&quot;event.stopPropagation(); EditRecipe({$RtempId},'".addslashes(json_encode($row2))."')&quot; style='margin:2px 0;'><!--<i class='far fa-edit'></i>--> Edit </button>
                    <button class='btn btn-primary' id='RecipeCopy' onclick=&quot;event.stopPropagation(); CopyRecipe({$RtempId},'".addslashes(json_encode($row2))."')&quot; style='margin:2px 0;'><!--<i class='far fa-clone'></i>--> Copy </button>
                    </div>
                  </div>
                 
                  <div id='cont-to-hide{$RtempId}' style='width:100%; display:none;'>
                    <div class='line'></div>
                  <div class='row'>
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center ' style='justify-content:center;'>

                      		<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text' ><strong>{$RtempFats}</strong><br><small class='prop'>Fat</small></div>

                      </div>
                      
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center' style='justify-content:center;'>

                      	<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text' style='padding-top: 10px;'><strong>{$RtempEnK}</strong><br><small class='prop'>Energy</small></div>

                      </div>
                  

                   	
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center' style='justify-content:center;'>

                      		<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text' ><strong>{$RtempCarbohydrate}</strong><br><small class='prop'>Carbohydrate</small></div>

                      </div>
                   
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center ' style='justify-content:center;'>

                      	<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text'><strong>{$RtempProtein}</strong><br><small class='prop'>Protein</small></div>

                      </div>
                  

                   
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center' style='justify-content:center;'>

                      		<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text'><strong>{$RtempFibre}</strong><br><small class='prop'>Fibre</small></div>

                      </div>
                      <div class=' col-lg-4 col-sm-6 d-flex align-items-center' style='justify-content:center;'>

                      	<div class='icon bg-green'><i class='fa fa-tasks'></i></div>
                    <div class='text'><strong>{$RtempWater}</strong><br><small class='prop'>Water</small></div>

                      </div>
                   </div>
		 <div class='line'></div>
                            <h3 class='h4' style='text-align:center; font-size:25px; '>Properties</h3>
                          <div class='row' style='justify-content: space-evenly;'>
                          ";
                           $arrchk=  json_decode($RtempProp); 
                           $sql3="select * from hRecipe_Property";
  $result3=mysqli_query($conn,$sql3);
  $chkcnt=0;
			  while($row = mysqli_fetch_assoc($result3))
			  {
			  if($arrchk[$chkcnt]=='true')
			  echo "<div class='i-checks' style='padding: 0 10px;'>
                              <input id='checkboxCustom' type='checkbox' value='' disabled='' checked='' class='checkbox-template'>
                              <label for='checkboxCustom'>".$row['PropName']."</label>
                            </div>";
			  $chkcnt++;
			  }
                         
                         echo "</div>    
                     
              
                 <div class='line'></div>
                            <h3 class='h4' style='text-align:center; font-size:25px; '>Steps of preparation</h3>
                <div class='row' style=' padding-left:10%;   align-items: center;'>
                            <ol class='list-group vertical-steps' id='stepscontainer'>
                           ";
                               
                             
                             foreach($Rtempstep as $temp){
                             
echo  "<li class='list-group-item active'><span>
   
      {$temp}
     
      </span></li>";
                             }  
 echo " </ol>

        </div>            
          </div>
              </div>
   </div>";
          
  }     
    
    }

}
else if($flag=="test"){

 $to = "suryashekhawat136@gmail.com";
 $subject = "Hey rcv me";
 $body = "<div> hi hi .. </div>";

    $headers = 'From: apache@server.formpicture.com' . "\r\n" ;
    $headers .='Reply-To: '. $to . "\r\n" ;
    $headers .='X-Mailer: PHP/' . phpversion();
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=iso-8859-1\r\n";   
if(mail($to, $subject, $body,$headers)) {
  echo('<br>'."Email Sent ;D ".'</br>');
  } 
  else 
  {
  echo("<p>Email Message delivery failed...</p>");
  }
}
/*require '/root/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '/root/vendor/phpmailer/phpmailer/src/SMTP.php';
require '/root/vendor/phpmailer/phpmailer/src/Exception.php';

 $email = new PHPMailer\PHPMailer\PHPMailer();
 $email->SMTPAuth = true;
    $email->IsSMTP(); 

$email->SetFrom('qqzz4546@formpicture.com', 'Surya Shekhawat'); //Name is optional
$email->Subject   = 'Hey test 1';
$email->Body      = 'hiiiiiiiiiiiiiiiiiiiiiiii';
$email->AddAddress( 'suryashekhawat136@gmail.com' );

//$file_to_attach = 'PATH_OF_YOUR_FILE_HERE';

//$email->AddAttachment( $file_to_attach , 'NameOfFile.pdf' );

if(!$email->Send()) {
        echo "Mailer Error: " . $email->ErrorInfo;
     } else {
        echo "Message has been sent";
     }
*/



function encryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

function decryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp';
    $qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
    return( $qDecoded );
} 
?>